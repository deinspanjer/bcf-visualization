# Handoff: BCF Visualization — Power Progression Redesign

## Overview

This is a redesign of the **Brockton's Celestial Forge** progression
visualization (https://github.com/deinspanjer/bcf-visualization).

The redesign reimagines the existing dependency-light scrubber UI as a
holographic Tinker-tech projection (in keeping with the in-universe
framing on the landing page where "Survey" projects this for Aisha), and
splits the experience into two modes:

- **Playthrough** — a cinematic "lean back" view: a panoramic carousel of
  the 14 cluster constellations drifts as the playhead advances; when a
  roll fires, the active constellation expands into a jump-focus overlay
  showing the mini-constellation of motes and the rolled mote highlighted,
  while a Field Log panel prints the actual evidence-quote prose from the
  story.

- **Detail** — a "lean forward" data-dense view: the same scrubber sits
  at top, and below it a grid of panels surfaces selected-chapter perks,
  recent acquisitions, per-constellation discovery progress, and a
  sortable/filterable roll log.

Both modes share a single horizontally-scrollable scrubber driven by
`word_position`, with the same playback controls (play/pause, speed,
zoom, on-roll behavior).

## About the Design Files

The files in this bundle are **design references created in HTML** —
prototypes showing intended look and behavior, **not production code to
copy directly**.

The prototype is implemented as **React + inline JSX transpiled by
Babel-standalone**, loaded as `<script type="text/babel" src="…">` tags
from a single HTML entry. This was chosen for rapid iteration during the
design process. The target project's existing `web/` app uses **vanilla
JS with no build step or external dependencies** (see
`bcf-visualization/web/app.js` upstream), and the redesign should be
**ported back to that same dependency-light architecture** rather than
shipping React as a runtime dependency. Most of the React code is plain
DOM manipulation in disguise — there's no significant component state
beyond `useState` for top-level scrubber position and mode, both of
which the existing app already manages via `localStorage`.

The data layer (`redesign/data.js`) is plain ES module JS and can be
moved into the target app with minimal change — it already reads the
same `data/derived/*.json` files the existing app reads.

## Fidelity

**High-fidelity** for visuals, layout, and interaction behaviour:
- Final color palette and typography are committed.
- Spacing, track sizes, font sizes, and pixel gaps are tuned.
- Diffraction-spike star markers preserve the existing recipe from
  `web/marker-samples.html` (theme "sun").

**Low-fidelity** for code:
- Component decomposition is rough; many components are 100–200 line
  functions that should be split when ported.
- No tests, no error boundaries, no a11y audit pass.

## Files in This Bundle

```
design_handoff_bcf_visualization/
├── README.md                            (this file)
├── Celestial Forge - Redesign.html      (entry point — open this)
└── redesign/
    ├── data.js          Async loader + normalizers + aggregations
    ├── star.jsx         Diffraction-spike star rendering (DiffractionMarker, SimpleStar)
    ├── scrubber.jsx     Multi-track scrubber + playback controls
    ├── playthrough.jsx  Playthrough mode (carousel + jump focus + field log)
    ├── detail.jsx       Detail mode (4-panel data grid)
    ├── app.jsx          App root, mode switch, playback loop, keyboard
    └── style.css        All styling
```

## Data Contract

The redesign consumes the same derived data bundle the existing app
expects (`data_package.json` manifest, `chapter_facts.json` runtime
backbone). All paths below are relative to `data/derived/`.

| File | Required | Used For |
|---|---|---|
| `chapter_facts.json` | yes | 194 chapters × {sections, rolls, constellation_progress, shadow_periods, in_world_timeline}. Authoritative source for chapter ordering, POV, word/CP counts, regime, perk acquisitions. |
| `constellation_wireframes.json` | yes | 14 cluster silhouettes + 214 jump star patterns. Drives carousel cards and jump-focus mini-skies. |
| `data_package.json` | yes | Manifest, version label shown in info popover. |
| `predicted_rolls.json` | optional | 562 mechanically-predicted roll positions through ch 119. Used for axis hairlines. Falls back to regime-derived synthetic schedule if missing. |

**Important: `predicted_rolls.json` reports `word_position` in
CP-EARNING-cumulative units, not raw cumulative.** The loader converts
to raw via the `rawWordAtCpEarning()` helper before placing ticks on
the scrubber's raw-word axis. See `data.js → load()`.

Beyond chapter 119 (the curated coverage of the current dataset),
predicted rolls are extrapolated via `buildSyntheticCpTicks()` in
`data.js` using the regime mechanics documented in
`docs/point_collection_and_spending_regimes.md`.

## Modes

### Playthrough mode

Layout: two columns. Left column is a `<div class="viewport">` with the
holographic frame chrome (corner brackets, scanline overlay, starfield),
holding a horizontally-translated `<div class="carousel-strip">` of 14
`<div class="const-card">` elements. Right column is a 360px-wide Field
Log panel.

**Carousel pan**: the active constellation (= the constellation of the
most-recent roll) is centered. CSS `transform: translateX(...)` moves
the strip with a 320ms ease. Cards either side of the active one are
faded and de-saturated.

**Jump focus**: appears as a floating panel in the bottom-right of the
viewport when a roll is firing (i.e. the playhead is within ±900 raw
words of the roll's word_position). Renders the jump's
`shape_concept`, draws all the jump's stars in their wireframe-defined
positions, fades unacquired stars, highlights the rolled mote as bright
white, and extends a golden "reach line" from the viewer origin
(bottom-center of the mini-sky) to that mote.

**Field log** (right column): prints `evidence_quotes` from the
roll directly. If `evidence_quotes` is empty, falls back to a
composed-from-data synopsis line that names the constellation and jump.
Never invents narrative text. When no roll is firing, shows a
clearly-non-narrative "NO LOG DATA · ch N · the Forge is between
reaches" placeholder.

User can hide the Field Log via the **−** glyph in its title bar; a
document glyph appears at the end of the scrubber's chapter readout to
reopen it.

### Detail mode

Layout: CSS grid, 3 columns × 2 rows. Top row: Selected chapter ·
Recent acquisitions · Constellation progress. Bottom row: Roll log
(spans all three columns).

**Selected chapter**: lists every perk acquired in the chapter
containing the playhead. Each row shows a small diffraction marker
sized by cost, the perk name (serif italic), and the source
(constellation · jump). Shows banked CP, structural markers
(`pho`, `news`, `meeting_report`), and a "recovery shadow" tag when the
chapter is inside a `shadow_period`.

**Recent acquisitions**: most-recent 14 perks (paid + free) across the
last 20 rolls before the playhead.

**Constellation progress**: 14 horizontal bars showing
`discovered / total` per cluster from
`chapter.constellation_progress`. Bar color = constellation hue. The
label clarifies that the percentage tracks perks DISCOVERED in catalog,
not just acquired.

**Roll log**: sortable (by roll # / chapter / paid CP), filterable (all /
hits / misses / multi-grabs). Clicking a row jumps the scrubber to that
roll's word position. Shows up to 250 rows of the filtered set; this is
a hard cap.

## Scrubber (Shared Between Modes)

Five horizontal tracks in a single panel, with vertically-aligned side
labels on the left (88px column) and a 240px chapter readout on the
right. The middle column is horizontally scrollable; its inner stack
width = `max(1200, total_kwords × 8.4px × zoom)`.

| # | Track | Height | Content |
|---|---|---|---|
| 1 | Dates | 32px | Three tiers stacked vertically: year ticks (full-height, always labelled), month ticks (medium, labelled when ≥ 28px gap), chapter-publish ticks (short, labelled with day-of-month ordinal when ≥ 22px gap). All labels gated against higher-priority labels. |
| 2 | Chapters | 18px | One tick per chapter (`major` class on decade chapters: 1, 10, 20, …). Every chapter gets a "ch N" label gated by 32px pixel gap. |
| 3 | POV / sections | 28px | One band per section (not per chapter). See "Section coloring" below. |
| 4 | Rolls | 96px | Hits centered ~38% from top, misses pinned to the bottom rail. Each roll renders as a `<DiffractionMarker>` colored by constellation. |
| 5 | Words / CP axis | 38px | Dual-tiered: raw-word ticks + labels at top (cadence chosen by zoom), CP-eligible-word ticks + labels (amber) at bottom positioned at the raw-word location where each CP threshold is crossed. Vertical hairlines spanning the axis for every predicted-roll trigger from `predicted_rolls.json`, color-coded by regime (1=amber, 2=violet, 3=rose). A 2px regime band at the very bottom shows which regime is in force across each raw-word range. |

**Auto-scroll**: the playhead pins to the center of the visible window
when playing. A 3-second deadband honours user-initiated horizontal
scrolls so they can pause-the-camera by scrolling manually.

**Playhead**: vertical cyan line with diamond pip at top and bottom,
draggable.

### Section coloring (POV / sections track)

Each section gets a colored band sized by raw `word_count`. Section
classification + marker_kind drive the treatment:

- **POV color** is derived from the section's `pov_character`:
  - `Joe` → always **blue** (oklch 0.62 0.14 196), regardless of section
    type. Joe's POV color is stable so the user reads "Joe" instantly.
  - Other POVs → hand-picked hue from `POV_HUE_OVERRIDES` (see
    `data.js`) for ~40 most-recurring characters; unknown characters
    fall back to a deterministic hash of the name (skipping 180–220 to
    stay clear of Joe's region).
- **Marker_kind** drives edge accents on top of the POV color:
  - `main_implicit` / `main_titled` → plain band.
  - `preamble` → 3px white left-edge bar with glow.
  - `addendum` → 3px white right-edge bar with glow.
  - `interlude` → 45° diagonal hatch overlay across the whole band.
  - `abilities` (the "Jumpchain abilities this chapter:" footer
    sections, which contribute zero CP) → a tiny 4px striped strip
    pinned to the band's bottom — visible but doesn't dominate.
  - `other` → plain band.
- **Recovery shadows** (chapters covered by `shadow_periods`) get a
  135° rose hatch overlay on top of whatever POV color is underneath,
  so both POV and recovery state are visible at a glance.

The full color palette is in `redesign/data.js → POV_HUE_OVERRIDES`.

## Diffraction-Spike Star Markers

The visualization's signature visual element. Preserved faithfully from
the user's existing tuning in `web/marker-samples.html`.

**Recipe** (in `redesign/star.jsx`):
- Cost buckets: 100 / 200 / 300 / 400 / 600 / 800 / 1000+ CP. Each
  bucket maps to a specific `(major rays, minor rays, ray length, ray
  width, glow lum, jitter)` tuple in `recipeFor()`.
- Five themes available (`thin`, `sun`, `sharp`, `lumin`, `prism`);
  only `sun` is used in the redesign. The user explicitly rejected the
  marker-theme tweak in an earlier review pass — themes are not
  user-selectable.
- Single perk: one star.
- Multi-grab (2 paid perks): "binary" — two stars offset ±6px.
- Multi-grab (3+ paid perks): "trinary" — three stars in a triangle.
- Free perks attached to a hit: tiny white satellite dots around the
  star (1, 2, or 3 of them).
- Misses: a single small star in pale blue/white (`#cfe9ff`) sized by
  `miss_cost_estimate`, rendered on the bottom rail of the rolls
  track. They read as faint sparkles, never as empty circles.

**SVG sizing**: `StarSvg` takes an explicit `pixelSize` prop and the
rays grow to fill it. `DiffractionMarker` computes
`pixelSize = clamp(46, markerSize × theme.spread, 124)` so rays are
visible even when the marker container is small. This is the same
46–112 clamp marker-samples.html uses; missing this clamp is what made
stars look like dots in earlier drafts.

## Playback

| Behavior | How |
|---|---|
| Play/pause | Space (global; works regardless of focus, blurs buttons before toggling so the bound `<button>` doesn't re-fire). Click button. |
| Step | ←/→ (10k words), Shift+←/→ (2k words fine). PageUp/Down jumps 100k. Home/End jumps to bounds. |
| Speed | 1k–100k words/sec via `<select>`. Default 25k. Stored in localStorage. |
| Zoom | 0.5–6× slider. Affects scrubber-stack width only. Stored. |
| Reset | Resets word position to 0 and pauses. |

**On-roll behavior**: a 3-state segmented control (matching the
Playthrough/Detail header switch visually):

- **normal** — playback proceeds through rolls at full speed.
- **pause** — when within ±700 raw words of a roll's position,
  auto-pause for 2.2s, then advance 1400 words and resume.
- **bullet time** — when within ±1500 raw words of a roll's position,
  drop playback speed to 0.04× (≈25× slower) so the user has ~3s to
  read the Field Log entry at the default 25k w/s speed. Auto-resumes
  full speed past the window.

These three are mutually exclusive (selecting one un-selects the others).

## Design Tokens

All defined in `redesign/style.css` `:root`:

```css
--void:         #03080d   /* page background base */
--void-deep:    #02060a
--void-soft:    #07121a
--ink:          #e8fdff   /* primary text */
--muted:        #9ad7df   /* secondary text */
--dim:          #5f9ba4   /* labels, ticks */
--cyan:         #5cf4ff   /* primary accent, playhead, active states */
--green:        #7bffbd   /* "field log" accents, positive state */
--amber:        #f5d27b   /* regime 1, CP-axis labels, reach line */
--rose:         #ff8aa8   /* regime 3, miss markers, recovery hatch */
--edge:         rgba(92, 244, 255, 0.56)   /* panel border (full) */
--edge-soft:    rgba(92, 244, 255, 0.22)
--edge-faint:   rgba(92, 244, 255, 0.08)
--glow:         rgba(92, 244, 255, 0.28)
--panel:        rgba(5, 29, 38, 0.50)
--panel-strong: rgba(5, 29, 38, 0.78)

--serif:        Georgia, "Times New Roman", serif        /* narrative prose */
--sans:         "Avenir Next", "Segoe UI", system-ui     /* headers */
--mono:         ui-monospace, SFMono-Regular, Menlo      /* tech / labels */
```

**Constellation hues** (`HUES` in `data.js`, chroma 0.13, lightness 0.78):

```
Toolkits 196 · Knowledge 268 · Vehicles 30 · Time 218 · Crafting 152
Clothing 320 · Magic 286 · Quality 48 · Size 100
Resources and Durability 8 · Magitech 240 · Alchemy 170
Capstone 52 · Personal Reality 130
```

**POV hues** (40+ in `POV_HUE_OVERRIDES`, chroma 0.14, lightness 0.62):

```
Joe 196 · Taylor 270 · Aisha 330 · Lisa 318 · Rachel 14 · Alec 60
Amy 130 · Vicky 70 · Dragon 142 · Colin 230 · Survey 184 · …
```

Joe's hue (196) matches the cyan accent — by design.

## Header

A single-row panel above the scrubber:

- **Title block** (left): `<h1>` linking to the SV threadmarks
  (`https://forums.sufficientvelocity.com/threads/brocktons-celestial-forge-worm-jumpchain.70036/threadmarks`),
  serif 20px, with "POWER PROGRESSION" caption below in green mono.
- **Story credits**: `Story by LordRoustabout` + 3 small site badges
  (`SV` `FF` `AO3`) linking to the canonical reading locations.
- **Keyboard cheat sheet**: a horizontal list of `<kbd>` chips
  (hidden under 1280px viewport width).
- **Mode switch**: segmented control with Playthrough/Detail buttons.
- **Info button** (`ⓘ`): opens a popover with project credits, GitHub
  link, data version label, and full keyboard shortcuts list.

## Portrait Viewport

A dismissable amber banner appears below the header when the viewport
is portrait or under 1100px wide, suggesting landscape. The user can
dismiss it permanently via localStorage; CSS media query handles the
visibility otherwise.

## Open Work / Next Items

Items still pending in this conversation:

1. **Sky view redesign** — the next major area of work. The existing
   prototype at `/web/?sky=1` is parked. The user wants:
   - A panoramic / carousel-like view where constellations are moving
     into view as the timeline progresses.
   - For each roll, zoom into the major constellation, then expand it
     into a shape that shows the "clusters" (jumps) within.
   - Capture the spirit of Joe's narrative descriptions of how the
     Forge "reaches" for power.
   - See `docs/phase4_sky_view_design.md` (in the project) for the
     original phase-4 design proposal.

   The current Playthrough's panoramic carousel is a starting point but
   the user wants a fuller "inside-out sphere" feel.

2. **Predicted roll coverage** — `predicted_rolls.json` currently only
   covers chapters 1–119. Chapters 120–194 use a synthetic schedule
   derived from regime mechanics. The user is working on curating more
   data; when re-curated bundles ship, drop them into `data/derived/`
   and the visualization picks them up automatically.

3. **Constellation card hull boundary** — currently the cards show a
   convex hull of jump anchor points as a faint silhouette. The
   wireframe data has a `shape_concept` text description (e.g.
   "open-end wrench / spanner: jaws on the left, long handle trailing
   right"). A more faithful silhouette polyline could be hand-authored
   per cluster, or the wireframe schema could be extended with an
   `outline_polyline` field.

4. **Sectioned synthetic narrative fallback** — when a roll has no
   `evidence_quotes`, the Field Log composes a brief structural line
   like "The Forge reached for the X constellation and grabbed a mote
   in the Y cluster". The user has flagged this as suspect (looks like
   a quote, isn't). Pending decision to either drop it for the same
   "no log data" placeholder, or tag it visibly as a synopsis.

5. **Detail mode "Most recent acquisitions"** — currently shows up to
   14 perks from the last 20 rolls. May want to surface mention
   chapter vs mechanical chapter distinctions for deferred-mention
   rolls (see `roll_facts` schema).

## Architecture Notes for the Implementing Developer

### React → vanilla port

The redesign is React + JSX for prototyping speed. The target codebase
is vanilla JS. Each redesign component maps to a corresponding piece in
the existing `web/app.js`. Rough mapping:

| Redesign file | Existing target |
|---|---|
| `redesign/data.js` | merge into `web/app.js` data loading or split into `web/data-contract.js` (already exists, similar role) |
| `redesign/star.jsx` `DiffractionMarker` | extract from existing `web/app.js` star rendering (already there as DOM-string templates, see `marker-samples.html`) and parameterize on `pixelSize` |
| `redesign/scrubber.jsx` | replaces `#track-stack` rendering in existing `web/app.js` |
| `redesign/playthrough.jsx` | new — no current equivalent. Implement as a separate render mode in app.js with a mode switch |
| `redesign/detail.jsx` | augments existing chapter detail / recent rail / constellation bars; tabularizes the roll log |
| `redesign/app.jsx` | merge mode switching + new keyboard handlers into existing app.js |
| `redesign/style.css` | merge with existing `web/style.css`; significant overlap on panel/scrubber styles |

### State

Persistence keys used (all under `bcf-redesign:` prefix in
localStorage — rename to match existing app's prefix when porting):

```
wordPos        word position (number)
speed          playback speed in words/sec (number)
zoom           scrubber zoom multiplier (number)
mode           "playthrough" | "detail"
pauseOnFire    boolean
bulletTime     boolean
fieldLogHidden boolean
portraitDismissed boolean
```

### Performance

- 194 chapters × ~3.5 sections each → ~680 section bands in DOM.
- 678 roll markers → 678 SVG diffraction stars in DOM.
- 562 predicted-roll hairlines (subsampled at low zoom via `targetMaxTicks`).
- 194 chapter ticks, 14 cluster cards × 14–32 jump nodes each in the
  carousel.

Stays smooth at zoom 1× on a 2020-era laptop. At zoom 6× the scrubber
stack is ~130k px wide; browser handles this fine but watch for memory
on mobile.

### Accessibility caveats

The redesign honors `prefers-reduced-motion` for the scanline drift
animation, but does not yet:
- ARIA-live the playhead position (the existing app does).
- Provide a non-canvas reading path for the sky view (per phase-4
  design doc, the scrubber view IS the accessible path).
- Tab-traversable roll markers.

The implementing developer should keep the existing app's
accessibility work and layer the redesign on top of it.

## Reading Order

If you're new to this codebase, read in this order:

1. `Celestial Forge - Redesign.html` (12 lines — entry point)
2. `redesign/style.css` (top ~200 lines for tokens + panel chrome)
3. `redesign/data.js` (entire — it defines the data surface)
4. `redesign/star.jsx` (entire — small, self-contained)
5. `redesign/scrubber.jsx` (entire — the densest piece)
6. `redesign/playthrough.jsx` then `redesign/detail.jsx`
7. `redesign/app.jsx` (puts it all together)

Upstream context worth pulling:
- `https://github.com/deinspanjer/bcf-visualization/blob/main/docs/phase4_sky_view_design.md`
- `https://github.com/deinspanjer/bcf-visualization/blob/main/docs/point_collection_and_spending_regimes.md`
- `https://github.com/deinspanjer/bcf-visualization/blob/main/web/marker-samples.html`
