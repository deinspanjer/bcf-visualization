/* Scrubber — DAW-style stack of tracks driven by word_position. */

function formatWords(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(2) + "M";
  if (n >= 1000) return (n / 1000).toFixed(0) + "k";
  return String(n);
}
function formatCpWords(n) {
  // CP-earning word counts get a "cp" suffix on labels so they don't blur
  // with raw-word numbers.
  return formatWords(n) + " cp";
}

// Months — used for the inter-year tick labels on the dates track.
const MONTH_ABBR = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

function ordinal(n) {
  // 1 → "1st", 2 → "2nd", … 21 → "21st", etc.
  const v = n % 100;
  if (v >= 11 && v <= 13) return n + "th";
  switch (n % 10) {
    case 1: return n + "st";
    case 2: return n + "nd";
    case 3: return n + "rd";
    default: return n + "th";
  }
}

// At zoom 1, density target: ~one diffraction marker per 28px in the densest
// stretch. Average inter-roll word distance is total/rolls; at ~678 rolls and
// 2.63M words, that's ~3,900 words/roll. Targeted base pixels per 1k words.
const BASE_PX_PER_KWORD = 8.4; // → ~33px/roll on average

function Scrubber({ wordPos, setWordPos, compact = false, theme = "sun", zoom = 1, playing = false, showFieldLogGlyph = false, onShowFieldLog }) {
  const { STORY, conByName, chapterAtWord, constellationColor, rawWordAtCpEarning, predictedRolls } = window.BCF;
  const scrollerRef = React.useRef(null);
  const stackRef = React.useRef(null);
  const total = STORY.total_words;
  const totalKwords = total / 1000;
  const stackPx = Math.max(1200, totalKwords * BASE_PX_PER_KWORD * zoom);

  const dragging = React.useRef(false);
  const handlePointer = (e) => {
    if (!stackRef.current) return;
    const rect = stackRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
    setWordPos(Math.round((x / rect.width) * total));
  };
  const onPointerDown = (e) => {
    dragging.current = true;
    handlePointer(e);
    e.target.setPointerCapture?.(e.pointerId);
  };
  const onPointerMove = (e) => { if (dragging.current) handlePointer(e); };
  const onPointerUp = (e) => {
    dragging.current = false;
    e.target.releasePointerCapture?.(e.pointerId);
  };

  // Auto-scroll to keep playhead centered, with a 3s deadband after a user-
  // initiated scroll.
  const userScrollAt = React.useRef(0);
  const lastAutoScroll = React.useRef(null);
  const onScroll = (e) => {
    if (lastAutoScroll.current != null
        && Math.abs(e.target.scrollLeft - lastAutoScroll.current) < 2) {
      lastAutoScroll.current = null;
      return;
    }
    userScrollAt.current = performance.now();
  };
  React.useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    const playheadX = (wordPos / total) * stackPx;
    const viewport = el.clientWidth;
    const centerX = playheadX - viewport / 2;
    const clamped = Math.max(0, Math.min(stackPx - viewport, centerX));
    const since = performance.now() - userScrollAt.current;
    const shouldFollow = !playing
      ? Math.abs(el.scrollLeft + viewport / 2 - playheadX) > viewport * 0.42
      : since > 3000;
    if (shouldFollow) {
      lastAutoScroll.current = clamped;
      el.scrollLeft = clamped;
    }
  }, [wordPos, stackPx, playing]);

  // ── Dates track ──────────────────────────────────────────────────────
  // Three tiers, vertically stacked: year (always labelled) > month (labelled
  // when ≥ 28px from prior month/year) > chapter publish day-of-month ordinal
  // (labelled when ≥ 22px from prior day/month/year). As zoom increases, more
  // tiers light up.
  const dateLayers = React.useMemo(() => {
    const yearTicks = [];
    const monthTicks = [];
    const chapterTicks = [];
    let lastYear = null, lastMonth = null;
    for (const ch of STORY.chapters) {
      if (!ch.publish_date) continue;
      const frac = ch.word_start / total;
      const y = ch.publish_date.slice(0, 4);
      const m = ch.publish_date.slice(5, 7);
      const d = parseInt(ch.publish_date.slice(8, 10), 10);
      // Chapter tick is emitted for every chapter.
      chapterTicks.push({ frac, day: d, key: ch.chapter_num });
      // Month tick is emitted only when month changes (and not at the
      // implicit "month changes because year changed" boundary).
      if (m !== lastMonth) {
        if (y === lastYear) monthTicks.push({ frac, month: m, key: `${y}-${m}` });
        lastMonth = m;
      }
      if (y !== lastYear) {
        yearTicks.push({ frac, year: y, key: y });
        lastYear = y;
        lastMonth = m;
      }
    }

    // Gating: walk each tier in order and skip labels too close to the
    // previously-emitted label on the same tier OR any higher-priority tier.
    const labelGapMonth = 28;
    const labelGapDay = 22;
    // Year labels are always shown — record their pixel positions to gate
    // month + day labels against them.
    const reservedPx = yearTicks.map(t => t.frac * stackPx).sort((a, b) => a - b);
    function reserveCheck(px, gap) {
      // Binary search would be nicer; this dataset is small enough not to.
      for (const r of reservedPx) {
        if (Math.abs(r - px) < gap) return false;
      }
      return true;
    }
    function reserveAdd(px) {
      reservedPx.push(px);
      // keep sorted enough for the linear scan
    }

    const monthLabels = [];
    for (const t of monthTicks) {
      const px = t.frac * stackPx;
      if (reserveCheck(px, labelGapMonth)) {
        monthLabels.push({ ...t, label: MONTH_ABBR[Number(t.month) - 1] });
        reserveAdd(px);
      }
    }
    const dayLabels = [];
    for (const t of chapterTicks) {
      const px = t.frac * stackPx;
      if (reserveCheck(px, labelGapDay)) {
        dayLabels.push({ ...t, label: ordinal(t.day) });
        reserveAdd(px);
      }
    }
    return { yearTicks, monthTicks, chapterTicks, monthLabels, dayLabels };
  }, [total, stackPx]);

  // Chapter ticks. Every chapter gets a tick; major-decade chapters get a
  // brighter mark. Labels are gated by pixel-gap so every chapter labels when
  // the user zooms in, but they thin out at low zoom to stay legible.
  const chapterTicks = React.useMemo(() =>
    STORY.chapters.map(ch => ({
      frac: ch.word_start / total,
      num: ch.chapter_num,
      major: ch.sort_key[0] % 10 === 0 || ch.chapter_num === "1",
    })),
  [total]);
  const chapterLabels = React.useMemo(() => {
    const gap = 32; // px between adjacent labels — fits "ch 120.1" comfortably
    let lastPx = -Infinity;
    const out = [];
    for (const ch of STORY.chapters) {
      const px = (ch.word_start / total) * stackPx;
      if (px - lastPx >= gap) {
        out.push({ frac: ch.word_start / total, num: ch.chapter_num });
        lastPx = px;
      }
    }
    return out;
  }, [total, stackPx]);

  // POV / section bands. We render one band per section, not per chapter.
  const sectionBands = React.useMemo(() => {
    return STORY.sections.map((s, i) => {
      const style = window.BCF.sectionStyle(s);
      // Decide marker_kind class. main_implicit/main_titled have no extra class.
      const kindClass = (s.marker_kind === "preamble" || s.marker_kind === "interlude" || s.marker_kind === "addendum")
        ? s.marker_kind
        : (s.marker_kind === "abilities" ? "meta" : "");
      return {
        key: `${s.chapter_num}#${s.section_index}`,
        left: (s.word_start / total) * 100,
        width: Math.max(0.02, ((s.word_end - s.word_start) / total) * 100),
        bandColor: style.color,
        cls: [style.mc ? "mc" : "", style.meta ? "meta" : "", kindClass].filter(Boolean).join(" "),
        title: `ch ${s.chapter_num} · ${s.marker_kind || "main"}${s.header ? ` · ${s.header}` : ""}${s.pov_character ? ` · pov ${s.pov_character}` : ""}`,
      };
    });
  }, [total, STORY]);

  // Recovery spans (overlaid on the POV/sections track).
  const recoverySpans = React.useMemo(() => {
    return (STORY.shadow_periods || []).map((s, i) => {
      const ch = STORY.chapters.find(c => c.chapter_num === s.trigger_chapter_num);
      if (!ch) return null;
      const shadowStart = ch.word_end;
      const shadowEnd = Math.min(total, shadowStart + (s.shadow_word_length || 0));
      return {
        left: (shadowStart / total) * 100,
        width: Math.max(0.05, ((shadowEnd - shadowStart) / total) * 100),
        title: `Recovery: ${s.trigger_perk_name} (${s.trigger_perk_cost} CP)`,
      };
    }).filter(Boolean);
  }, [total]);

  // ── Axis tick computations ───────────────────────────────────────────
  // Raw word ticks (top of axis): smart cadence based on zoom.
  const wordTicks = React.useMemo(() => {
    const targetPx = 120;
    const desiredKwords = (targetPx / BASE_PX_PER_KWORD) / zoom;
    let step;
    if (desiredKwords < 75) step = 50000;
    else if (desiredKwords < 150) step = 100000;
    else if (desiredKwords < 300) step = 200000;
    else if (desiredKwords < 600) step = 500000;
    else step = 1000000;
    const out = [];
    for (let w = 0; w <= total; w += step) {
      out.push({ frac: w / total, label: formatWords(w) });
    }
    return out;
  }, [total, zoom]);

  // CP-eligible word ticks (bottom of axis): same cadence selection in
  // CP-word units, mapped back to raw position so they align under the raw
  // axis but at the correct point in CP-earning space.
  const cpTicks = React.useMemo(() => {
    const targetPx = 120;
    const desiredKwords = (targetPx / BASE_PX_PER_KWORD) / zoom;
    let step;
    if (desiredKwords < 75) step = 50000;
    else if (desiredKwords < 150) step = 100000;
    else if (desiredKwords < 300) step = 200000;
    else if (desiredKwords < 600) step = 500000;
    else step = 1000000;
    const totalCp = STORY.chapters[STORY.chapters.length - 1]?.cp_cum_end ?? 0;
    const out = [];
    for (let c = 0; c <= totalCp; c += step) {
      const raw = rawWordAtCpEarning(c);
      out.push({ frac: raw / total, label: formatCpWords(c) });
    }
    return out;
  }, [total, zoom, STORY]);

  // Predicted-roll trigger hairlines. Skip rendering if there are too many
  // for the current zoom (zooming out below 1× makes 600+ predicted ticks
  // look like a solid wash); at low zoom, sub-sample.
  const predictedTicks = React.useMemo(() => {
    const arr = predictedRolls || [];
    // Subsample if needed: only render every Nth tick at low zoom.
    const targetMaxTicks = Math.max(200, Math.min(800, Math.round(stackPx / 6)));
    const stride = Math.max(1, Math.ceil(arr.length / targetMaxTicks));
    const out = [];
    for (let i = 0; i < arr.length; i += stride) {
      const p = arr[i];
      // Key must be unique. roll_number is unique in the curated data; for
      // synthetic backfill we fall back to the raw word position (also unique
      // because triggers are monotonic on the timeline).
      const key = p.roll_number != null ? `roll-${p.roll_number}` : `wp-${p.word_position}`;
      out.push({
        frac: p.word_position / total,
        regime: p.regime,
        key,
      });
    }
    return out;
  }, [predictedRolls, total, stackPx]);

  // Regime underlay bands.
  const regimeBands = React.useMemo(() => {
    const out = [];
    let runStart = 0;
    let runRegime = STORY.chapters[0]?.regime || 1;
    for (let i = 0; i < STORY.chapters.length; i++) {
      const ch = STORY.chapters[i];
      if (ch.regime !== runRegime) {
        out.push({
          regime: runRegime,
          left: (runStart / total) * 100,
          width: ((ch.word_start - runStart) / total) * 100,
        });
        runStart = ch.word_start;
        runRegime = ch.regime;
      }
    }
    out.push({
      regime: runRegime,
      left: (runStart / total) * 100,
      width: ((total - runStart) / total) * 100,
    });
    return out;
  }, [total, STORY]);

  const fraction = total > 0 ? wordPos / total : 0;
  const currentChapter = chapterAtWord(wordPos);

  return (
    <div className="panel panel-cut scrubber" style={{ minHeight: compact ? 168 : 232 }}>
      <div className="scrubber-side">
        <span className="label-dates">dates</span>
        <span className="label-chapters">chapters</span>
        <span className="label-pov">pov / sections</span>
        <span className="label-rolls">rolls</span>
        <span className="label-axis">
          words
          <span className="sub">total / cp</span>
        </span>
      </div>
      <div
        className="scrubber-scroller"
        ref={scrollerRef}
        onScroll={onScroll}
      >
        <div
          ref={stackRef}
          className="scrubber-stack"
          style={{ width: stackPx }}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
        >
          {/* Dates track: stacked tiers — year (always labelled), month (gated),
              chapter publish day-of-month ordinal (gated). */}
          <div className="scrubber-track dates">
            {dateLayers.yearTicks.map(t => (
              <span key={`yt-${t.key}`} className="tick year" style={{ left: `${t.frac * 100}%` }} />
            ))}
            {dateLayers.monthTicks.map(t => (
              <span key={`mt-${t.key}`} className="tick month" style={{ left: `${t.frac * 100}%` }} />
            ))}
            {dateLayers.chapterTicks.map(t => (
              <span key={`ct-${t.key}`} className="tick chapter-pub" style={{ left: `${t.frac * 100}%` }} />
            ))}
            {dateLayers.yearTicks.map(t => (
              <span key={`yl-${t.key}`} className="tick-label year" style={{ left: `${t.frac * 100}%` }}>{t.year}</span>
            ))}
            {dateLayers.monthLabels.map(t => (
              <span key={`ml-${t.key}`} className="tick-label month" style={{ left: `${t.frac * 100}%` }}>{t.label}</span>
            ))}
            {dateLayers.dayLabels.map(t => (
              <span key={`dl-${t.key}`} className="tick-label day" style={{ left: `${t.frac * 100}%` }}>{t.label}</span>
            ))}
          </div>

          {/* Chapters track */}
          <div className="scrubber-track chapters">
            {chapterTicks.map((t) => (
              <span key={`ct-${t.num}`} className={`ch-mark ${t.major ? "major" : ""}`} style={{ left: `${t.frac * 100}%` }} />
            ))}
            {chapterLabels.map((t) => (
              <span key={`cl-${t.num}`} className="ch-num" style={{ left: `${t.frac * 100}%` }}>ch {t.num}</span>
            ))}
          </div>

          {/* POV / sections track — one band per section. */}
          <div className="scrubber-track pov">
            {sectionBands.map(b => (
              <span
                key={b.key}
                className={`pov-band ${b.cls}`}
                style={{ left: `${b.left}%`, width: `${b.width}%`, "--bandColor": b.bandColor }}
                title={b.title}
              />
            ))}
            {recoverySpans.map((s, i) => (
              <span key={`rec-${i}`} className="pov-band recovery" style={{ left: `${s.left}%`, width: `${s.width}%`, "--bandColor": "transparent" }} title={s.title} />
            ))}
          </div>

          {/* Rolls track */}
          <div className="scrubber-track rolls">
            {STORY.rolls.map(r => {
              const frac = r.word_position / total;
              const color = constellationColor(r.constellation);
              return (
                <span
                  key={r.uid}
                  className={`roll-marker ${r.outcome === "miss" ? "miss-marker" : ""}`}
                  style={{ left: `${frac * 100}%` }}
                  onClick={(e) => { e.stopPropagation(); setWordPos(r.word_position); }}
                  title={`Roll #${r.roll_number} · ${r.outcome.toUpperCase()} · ${r.constellation || "—"}`}
                >
                  <DiffractionMarker roll={r} themeKey={theme} scale={compact ? 0.85 : 1.1} color={color} />
                </span>
              );
            })}
          </div>

          {/* Axis: raw word ticks (top), CP-eligible word ticks (bottom),
              predicted-roll trigger hairlines, regime band. */}
          <div className="scrubber-track axis">
            {predictedTicks.map((p) => (
              <span
                key={`pt-${p.key}`}
                className={`predicted-tick regime-${p.regime}`}
                style={{ left: `${p.frac * 100}%` }}
              />
            ))}
            {wordTicks.map(t => (
              <React.Fragment key={`raw-${t.label}`}>
                <span className="word-tick" style={{ left: `${t.frac * 100}%` }} />
                <span className="word-tick-label" style={{ left: `${t.frac * 100}%` }}>{t.label}</span>
              </React.Fragment>
            ))}
            {cpTicks.map(t => (
              <React.Fragment key={`cp-${t.label}`}>
                <span className="cp-tick" style={{ left: `${t.frac * 100}%` }} />
                <span className="cp-tick-label" style={{ left: `${t.frac * 100}%` }}>{t.label}</span>
              </React.Fragment>
            ))}
            {regimeBands.map((b, i) => (
              <span
                key={`rb-${i}`}
                className={`regime-band regime-${b.regime}`}
                style={{ left: `${b.left}%`, width: `${b.width}%` }}
                title={`regime ${b.regime}`}
              />
            ))}
          </div>

          <div className="scrubber-playhead" style={{ left: `${fraction * 100}%` }} />
        </div>
      </div>
      <div className="scrubber-readout">
        <span className="readout-chapter">ch {currentChapter.chapter_num} · {currentChapter.pov}</span>
        <span className="readout-title">{currentChapter.title}</span>
        <span className="readout-meta">
          {currentChapter.publish_date} · word {formatWords(wordPos)} / {formatWords(total)}
          {currentChapter.banked_cp_at_end != null && <> · {currentChapter.banked_cp_at_end} CP banked</>}
          {showFieldLogGlyph && (
            <button
              type="button"
              className="readout-glyph"
              onClick={onShowFieldLog}
              aria-label="Show field log"
              title="Show field log"
            >
              <svg viewBox="0 0 16 16" aria-hidden="true">
                <path d="M3.5 1.5 H10 L12.5 4 V14.5 H3.5 Z" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />
                <path d="M10 1.5 V4 H12.5" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />
                <path d="M5.5 7 H10.5 M5.5 9.5 H10.5 M5.5 12 H8.5" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
              </svg>
            </button>
          )}
        </span>
      </div>
    </div>
  );
}

function ScrubberControls({
  playing, setPlaying, speed, setSpeed, zoom, setZoom, onReset,
  pauseOnFire, setPauseOnFire, bulletTime, setBulletTime,
}) {
  return (
    <div className="scrubber-controls">
      <button className="btn icon primary" onClick={() => setPlaying(!playing)} aria-label={playing ? "Pause" : "Play"} title={playing ? "Pause (space)" : "Play (space)"}>
        {playing ? "❚❚" : "▶"}
      </button>
      <label className="control-label">
        speed
        <select value={speed} onChange={e => setSpeed(Number(e.target.value))}>
          <option value="1000">1k w/s</option>
          <option value="2500">2.5k w/s</option>
          <option value="5000">5k w/s</option>
          <option value="10000">10k w/s</option>
          <option value="25000">25k w/s</option>
          <option value="50000">50k w/s</option>
          <option value="100000">100k w/s</option>
        </select>
      </label>
      <label className="control-label">
        zoom
        <input type="range" min="0.5" max="6" step="0.05" value={zoom} onChange={e => setZoom(Number(e.target.value))} />
        <span style={{ minWidth: 28, color: "var(--ink)" }}>{zoom.toFixed(2)}×</span>
      </label>

      <span className="control-divider" aria-hidden="true" />
      <span className="control-label" style={{ marginRight: -6 }}>on roll</span>
      <div className="app-mode-switch roll-mode-switch" role="group" aria-label="Behavior when the Forge fires a roll">
        <button
          className={!pauseOnFire && !bulletTime ? "is-active" : ""}
          onClick={() => { setPauseOnFire(false); setBulletTime(false); }}
          title="Keep playing through rolls at normal speed"
        >normal</button>
        <button
          className={pauseOnFire ? "is-active" : ""}
          onClick={() => setPauseOnFire(true)}
          aria-pressed={pauseOnFire}
          title="Pause playback when the Forge fires a roll"
        >pause</button>
        <button
          className={bulletTime ? "is-active" : ""}
          onClick={() => setBulletTime(true)}
          aria-pressed={bulletTime}
          title="Slow playback during a roll so you can read the moment"
        >bullet time</button>
      </div>

      <button className="btn ghost" onClick={onReset}>reset</button>
    </div>
  );
}

Object.assign(window, { Scrubber, ScrubberControls, formatWords });
