/* Real-data loader. Fetches the three derived JSON bundles produced by the
   pipeline and normalizes them into a single window.BCF surface so the
   render code stays simple. Loader is async: call BCF.load() once at app
   start and await it before rendering.

   Files consumed (all under data/derived/):
     - chapter_facts.json          (visualization backbone — 194 chapters, 678 rolls)
     - constellation_wireframes.json (14 cluster silhouettes + 214 jump star patterns)
     - data_package.json           (manifest — version label only)
*/

const DERIVED = "data/derived";

async function fetchJson(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed to load ${path}: ${res.status}`);
  return res.json();
}

// Andrew's monotone chain — used to give each constellation card a faint
// silhouette boundary that implies the shape its vertices were drawn against.
// The wireframe vertices are sorted by perk count, not spatial order, so we
// compute the hull ourselves rather than connecting in source order.
function convexHull(points) {
  const pts = points.slice().sort((a, b) => a.x - b.x || a.y - b.y);
  if (pts.length <= 2) return pts;
  const cross = (O, A, B) => (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
  const lower = [];
  for (const p of pts) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper = [];
  for (let i = pts.length - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
    upper.push(p);
  }
  upper.pop();
  lower.pop();
  return lower.concat(upper);
}

const CONSTELLATION_ORDER = [
  "Toolkits", "Knowledge", "Vehicles", "Time", "Crafting",
  "Clothing", "Magic", "Quality", "Size",
  "Resources and Durability", "Magitech", "Alchemy",
  "Capstone", "Personal Reality",
];

// Hand-picked hues at matched chroma/lightness so they read as one palette
// against the cyan-on-void chrome. Keep a CVD-friendly spread.
const HUES = {
  "Toolkits": 196,
  "Knowledge": 268,
  "Vehicles": 30,
  "Time": 218,
  "Crafting": 152,
  "Clothing": 320,
  "Magic": 286,
  "Quality": 48,
  "Size": 100,
  "Resources and Durability": 8,
  "Magitech": 240,
  "Alchemy": 170,
  "Capstone": 52,
  "Personal Reality": 130,
};

function constellationColor(name) {
  const h = HUES[name] ?? 196;
  return `oklch(0.78 0.13 ${h})`;
}

// ── POV / section coloring ──────────────────────────────────────────────
// Each POV character gets a distinct hue. Joe is always Joe's blue — anytime
// Joe is the POV (full chapter, preamble, addendum), the band reads the same.
// Other characters hash to a stable hue, kept clear of Joe's region (180–220)
// and of the meta-gray space (around 0 chroma).

const POV_HUE_OVERRIDES = {
  // Hand-picked for the most-recurring non-Joe POVs so they read distinctively.
  "Joe": 196,
  "Taylor": 270,
  "Aisha": 330,
  "Lisa": 318,
  "Rachel": 14,
  "Alec": 60,
  "Amy": 130,
  "Vicky": 70,
  "Dragon": 142,
  "Colin": 230,
  "Survey": 184,
  "Hannah": 38,
  "Rory": 22,
  "Sophia": 282,
  "Emily": 350,
  "Missy": 158,
  "Chen": 246,
  "James": 92,
  "Mike": 304,
  "Accord": 50,
  "Tammi": 4,
  "Leet": 110,
  "Gully": 200, // close to joe but pushed; rarely co-occurs
  "Jeanne": 340,
  "Carol": 96,
  "Uppercrust": 28,
  "Margaret": 122,
  "Ethan": 168,
  "Chris": 220,
  "Kenta": 354,
  "Mimi": 26,
  "Marissa": 312,
  "Rey": 188,
  "Hemorrhagia": 358,
  "Legend": 218,
  "Emma": 308,
  "The Bay": 56,
  "Meeting Report": 64,
  "Lily": 286,
  "Everett": 174,
  "Elle": 296,
  "Keith": 84,
};

function hashPovHue(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = ((h * 31) + name.charCodeAt(i)) | 0;
  // Map to 0–319, then skip a 40° gap around Joe's blue (180–220) so colors
  // stay visually distinct from the protagonist's POV band.
  let hue = Math.abs(h) % 320;
  if (hue >= 180) hue += 40;
  return hue;
}

function povColor(povName) {
  if (!povName) return { hue: null, color: "var(--dim)" };
  const hue = POV_HUE_OVERRIDES[povName] ?? hashPovHue(povName);
  return { hue, color: `oklch(0.62 0.14 ${hue})` };
}

// Section visual treatment, used by the scrubber's POV/sections track.
function sectionStyle(section) {
  const isMc = section.classification === "mc";
  const isMeta = section.classification === "non_mc_meta";
  if (isMeta) {
    return { color: "rgba(154, 215, 223, 0.22)", hue: null, mc: false, meta: true };
  }
  const povName = isMc ? "Joe" : (section.pov_character || null);
  if (!povName) {
    // Unattributed non-MC sections (e.g. PHO addenda) — use a generic warm hue.
    return { color: "oklch(0.62 0.12 38)", hue: 38, mc: false, meta: false };
  }
  const { hue, color } = povColor(povName);
  return { color, hue, mc: isMc, meta: false, povName };
}

// ── CP-eligible word interpolation ──────────────────────────────────────
// Given a raw cumulative word position, return the cumulative CP-earning
// word count. Linear interpolation within the containing chapter (true to
// the model: a chapter's CP-earning content is contiguous).

function cpEarningAt(rawWords, story) {
  if (rawWords <= 0) return 0;
  for (const ch of story.chapters) {
    if (rawWords < ch.word_start) return ch.cp_cum_start;
    if (rawWords <= ch.word_end) {
      const rawSpan = ch.word_end - ch.word_start;
      const cpSpan = ch.cp_cum_end - ch.cp_cum_start;
      if (rawSpan === 0) return ch.cp_cum_end;
      return ch.cp_cum_start + ((rawWords - ch.word_start) / rawSpan) * cpSpan;
    }
  }
  return story.chapters[story.chapters.length - 1]?.cp_cum_end ?? 0;
}

// Inverse: given a target CP-earning word count, return the raw word position
// where that threshold is reached.
function rawWordAtCpEarning(targetCp, story) {
  if (targetCp <= 0) return 0;
  for (const ch of story.chapters) {
    if (ch.cp_cum_end >= targetCp) {
      const rawSpan = ch.word_end - ch.word_start;
      const cpSpan = ch.cp_cum_end - ch.cp_cum_start;
      if (cpSpan === 0) continue; // chapter contributed no CP-earning words; skip
      const need = targetCp - ch.cp_cum_start;
      return ch.word_start + (need / cpSpan) * rawSpan;
    }
  }
  return story.total_words;
}

// Regime-aware CP threshold spacing. Returns the CP increment between
// predicted-roll triggers for a given regime number.
function cpStepForRegime(regime) {
  // Regime 1 (ch 1–91): roll every 100 CP
  // Regime 2 (ch 92–96): roll every 200 CP
  // Regime 3 (ch 97+):   roll every 200 CP (slower earning rate handled
  //                      naturally via cp_earning_word_count)
  return regime === 1 ? 100 : 200;
}

// Words-per-100-CP earning rate per regime — used to label the CP axis with
// raw-word-equivalent gaps so the user can see "this region earns slower".
function wordsPer100CpForRegime(regime) {
  return regime === 3 ? 3000 : 2000;
}

// Build a list of synthetic CP threshold tick positions from regime mechanics
// alone, in case predicted_rolls.json is not available. Each tick is the
// raw-word position where the next roll trigger crosses its CP threshold.
function buildSyntheticCpTicks(story) {
  const ticks = [];
  let runningCp = 0;          // total CP earned so far across the story
  let nextTrigger = 100;      // first regime-1 trigger fires at 100 CP
  for (const ch of story.chapters) {
    const wordsPer100 = wordsPer100CpForRegime(ch.regime);
    const cpThisChapter = ((ch.cp_cum_end - ch.cp_cum_start) / wordsPer100) * 100;
    const cpStart = runningCp;
    const cpEnd = runningCp + cpThisChapter;
    const step = cpStepForRegime(ch.regime);
    while (nextTrigger <= cpEnd) {
      if (nextTrigger >= cpStart && cpThisChapter > 0) {
        const within = (nextTrigger - cpStart) / cpThisChapter; // 0..1
        const rawPos = ch.word_start + within * (ch.word_end - ch.word_start);
        ticks.push({
          word_position: Math.round(rawPos),
          chapter_num: ch.chapter_num,
          regime: ch.regime,
          cp_threshold: Math.round(nextTrigger),
        });
      }
      nextTrigger += step;
      if (ticks.length > 8000) return ticks; // safety guard
    }
    runningCp = cpEnd;
  }
  return ticks;
}

function buildConstellations(wireframes) {
  const byName = new Map(wireframes.cluster_constellations.map(c => [c.name, c]));
  // Index jump-level wireframes by `constellation::jump`
  const jumpsByKey = new Map();
  for (const j of wireframes.jump_constellations) {
    jumpsByKey.set(`${j.constellation}::${j.jump}`, j);
  }

  const result = [];
  for (const name of CONSTELLATION_ORDER) {
    const c = byName.get(name);
    if (!c) continue;
    // Compute hull boundary for the cluster card silhouette.
    const pts = c.cluster_vertices.map(v => ({ x: v.x, y: v.y, jump: v.jump }));
    const hull = convexHull(pts);
    // Compute bbox for normalization to a unit square inside the card.
    const xs = pts.map(p => p.x);
    const ys = pts.map(p => p.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    // Avoid singularities.
    const w = Math.max(0.01, maxX - minX);
    const h = Math.max(0.01, maxY - minY);
    // Normalize to [0.08, 0.92] so the silhouette has padding inside the card.
    const norm = (p) => ({
      x: 0.08 + ((p.x - minX) / w) * 0.84,
      y: 0.08 + ((p.y - minY) / h) * 0.84,
    });

    const vertices = pts.map(p => {
      const n = norm(p);
      const jumpWf = jumpsByKey.get(`${name}::${p.jump}`);
      const perkCount = jumpWf?.stars?.length ?? 1;
      return { jump: p.jump, x: n.x, y: n.y, perkCount, jumpWf };
    });
    const hullN = hull.map(p => norm(p));

    result.push({
      name,
      hue: HUES[name] ?? 196,
      shape_concept: c.shape_concept,
      vertices,
      hull: hullN,
    });
  }
  return result;
}

function normChapterTitle(full_title, chapter_num) {
  // Strip the "1 " / "120.1 " prefix that mirrors chapter_num.
  const prefix = chapter_num + " ";
  if (full_title.startsWith(prefix)) return full_title.slice(prefix.length);
  return full_title;
}

function buildStory(chapterFacts) {
  const chapters = [];
  const rolls = [];
  const sections = []; // Flat list of all sections, with absolute word ranges.
  let runningStart = 0;
  let runningCpCum = 0; // tracks cumulative_cp_earning_words for prev-chapter anchor
  for (const ch of chapterFacts.chapters) {
    const wordStart = runningStart;
    const wordEnd = ch.cumulative_words_through_chapter;
    runningStart = wordEnd;
    const cpCumStart = runningCpCum;
    runningCpCum = ch.cumulative_cp_earning_words;

    const chapter = {
      chapter_num: ch.chapter_num,
      sort_key: ch.sort_key,
      title: normChapterTitle(ch.full_title, ch.chapter_num),
      full_title: ch.full_title,
      pov: (ch.pov_characters || [])[0] || "Joe",
      pov_characters: ch.pov_characters || [],
      structural_markers: ch.structural_markers || [],
      regime: ch.point_calculation_regime,
      word_start: wordStart,
      word_end: wordEnd,
      total_word_count: ch.total_word_count,
      cp_earning_word_count: ch.cp_earning_word_count,
      cp_cum_start: cpCumStart,
      cp_cum_end: ch.cumulative_cp_earning_words,
      publish_date: (ch.published_at || "").slice(0, 10),
      published_at: ch.published_at,
      post_url: ch.post_url,
      likes: ch.likes,
      banked_cp_at_start: ch.banked_cp_at_start,
      banked_cp_at_end: ch.banked_cp_at_end,
      perks_gained: ch.perks_gained,
      paid_perks_gained: ch.paid_perks_gained,
      free_perks_gained: ch.free_perks_gained,
      rolls_count: ch.rolls_count,
      hits_count: ch.hits_count,
      misses_count: ch.misses_count,
      constellation_progress: ch.constellation_progress || [],
      sections: ch.sections || [],
      recovery: false, // filled in below from shadow_periods
      rolls: [],
    };

    // Sections — each has a raw word_count. Order they appear in `sections`
    // matches their narrative order. We accumulate to get absolute word
    // positions for the POV/sections track.
    let sectOffset = wordStart;
    for (const s of ch.sections || []) {
      const sWordCount = s.word_count || 0;
      const sStart = sectOffset;
      const sEnd = sectOffset + sWordCount;
      sectOffset = sEnd;
      sections.push({
        chapter_num: ch.chapter_num,
        section_index: s.section_index,
        marker_kind: s.marker_kind,
        classification: s.classification,
        pov_character: s.pov_character || (s.classification === "mc" ? "Joe" : null),
        header: s.header,
        word_count: sWordCount,
        cp_earning_word_count: s.cp_earning_word_count || 0,
        counts_for_cp: !!s.counts_for_cp,
        structural_markers: s.structural_markers || [],
        word_start: sStart,
        word_end: sEnd,
      });
    }

    for (let i = 0; i < (ch.rolls || []).length; i++) {
      const r = ch.rolls[i];
      // Guaranteed-unique id — roll_number can repeat across curator/fallback
      // rows, and is sometimes null. We always have chapter_num + sequence.
      const uid = `${ch.chapter_num}#${r.roll_sequence_in_chapter ?? i + 1}`;
      // Word position: prefer display_cumulative_word_offset; fall back to
      // mention or source; finally to chapter midpoint so we always have a
      // position to render at.
      const wp =
        r.display_cumulative_word_offset ??
        r.cumulative_word_offset ??
        r.source_cumulative_word_offset ??
        ((wordStart + wordEnd) / 2);
      const jump = r.purchased_perk_jump
        || (r.free_perks?.[0]?.jump)
        || null;
      const roll = {
        uid,
        roll_number: r.roll_number ?? `${ch.chapter_num}.${i + 1}`,
        chapter_num: ch.chapter_num,
        mechanical_chapter_num: r.mechanical_chapter_num,
        display_chapter_num: r.display_chapter_num,
        outcome: r.outcome,
        constellation: r.constellation,
        jump,
        word_position: Math.round(wp),
        purchased_perks: r.purchased_perks || [],
        free_perks: r.free_perks || [],
        purchased_perk_jump: r.purchased_perk_jump,
        rolled_perk_name: r.rolled_perk_name,
        rolled_perk_cost: r.rolled_perk_cost,
        miss_cost_estimate: r.miss_cost_estimate,
        available_cp: r.available_cp,
        banked_cp_after_roll: r.banked_cp_after_roll,
        evidence_kind: r.evidence_kind,
        evidence_quotes: r.evidence_quotes || [],
        source_kind: r.source_kind,
        fact_source: r.fact_source,
        roll_sequence_in_chapter: r.roll_sequence_in_chapter,
        post_url: ch.post_url,
        publish_date: chapter.publish_date,
        chapter_title: chapter.title,
      };
      chapter.rolls.push(roll);
      rolls.push(roll);
    }

    chapters.push(chapter);
  }

  // Mark chapters covered by recovery shadow periods.
  const chByNum = new Map(chapters.map(c => [c.chapter_num, c]));
  for (const s of (chapterFacts.shadow_periods || [])) {
    const start = chByNum.get(s.trigger_chapter_num);
    const end = chByNum.get(s.shadow_end_chapter_num);
    if (!start || !end) continue;
    const startIdx = chapters.indexOf(start);
    const endIdx = chapters.indexOf(end);
    for (let i = startIdx; i <= endIdx; i++) {
      chapters[i].recovery = true;
      chapters[i].recovery_trigger = s.trigger_perk_name;
    }
  }

  // Sort rolls by word_position so timeline iteration is monotonic.
  rolls.sort((a, b) => a.word_position - b.word_position);

  const total_words = chapters[chapters.length - 1]?.word_end ?? 0;
  return { chapters, rolls, sections, total_words, shadow_periods: chapterFacts.shadow_periods || [] };
}

// ── Aggregation helpers ─────────────────────────────────────────────────

function chapterAtWord(wordPos, story) {
  for (const ch of story.chapters) {
    if (wordPos >= ch.word_start && wordPos <= ch.word_end) return ch;
  }
  // If past the end:
  if (wordPos > 0) return story.chapters[story.chapters.length - 1];
  return story.chapters[0];
}

function lastRollAtWord(wordPos, story) {
  let last = null;
  for (const r of story.rolls) {
    if (r.word_position > wordPos) break;
    last = r;
  }
  return last;
}

function recentRolls(wordPos, n, story) {
  const out = [];
  for (let i = story.rolls.length - 1; i >= 0 && out.length < n; i--) {
    const r = story.rolls[i];
    if (r.word_position <= wordPos) out.push(r);
  }
  return out;
}

function cumulativeAt(wordPos, story) {
  // Use the chapter row's pre-computed cumulative values where possible.
  const ch = chapterAtWord(wordPos, story);
  let paid = 0, free = 0, hits = 0, miss = 0;
  for (const r of story.rolls) {
    if (r.word_position > wordPos) break;
    if (r.outcome === "hit") {
      hits += 1;
      paid += r.purchased_perks.length;
      free += r.free_perks.length;
    } else if (r.outcome === "miss") {
      miss += 1;
    }
  }
  return {
    chapters: ch?.sort_key?.[0] ?? 0,
    chapter_label: ch?.chapter_num ?? "?",
    words: wordPos,
    paid,
    free,
    hits,
    miss,
    banked_cp: ch?.banked_cp_at_end ?? null,
  };
}

// ── Loader entry point ─────────────────────────────────────────────────

let _loaded = null;

async function load() {
  if (_loaded) return _loaded;
  const [chapterFacts, wireframes, pkg, predictedRollsRaw] = await Promise.all([
    fetchJson(`${DERIVED}/chapter_facts.json`),
    fetchJson(`${DERIVED}/constellation_wireframes.json`),
    fetchJson(`${DERIVED}/data_package.json`).catch(() => null),
    fetchJson(`${DERIVED}/predicted_rolls.json`).catch(() => null),
  ]);
  const story = buildStory(chapterFacts);
  const constellations = buildConstellations(wireframes);
  const conByName = Object.fromEntries(constellations.map(c => [c.name, c]));
  const jumpWireframeByKey = new Map();
  for (const j of wireframes.jump_constellations) {
    jumpWireframeByKey.set(`${j.constellation}::${j.jump}`, j);
  }

  // Predicted-roll positions. Prefer the curated file; fall back to a
  // regime-derived schedule so the words track always has something to show.
  //
  // NOTE: the curated `predicted_rolls.json` reports `word_position` in
  // CP-EARNING-cumulative units (not raw cumulative). We convert to raw
  // here so the renderer can position ticks against the raw-word axis it
  // uses everywhere else.
  let predictedRolls = [];
  if (predictedRollsRaw?.predicted) {
    for (const p of predictedRollsRaw.predicted) {
      predictedRolls.push({
        word_position: Math.round(rawWordAtCpEarning(p.word_position, story)),
        cp_word_position: p.word_position,
        chapter_num: p.chapter_num,
        regime: p.cp_rule_regime,
        cp_threshold: p.roll_trigger_cp_threshold,
        roll_number: p.roll_number,
        source: "curated",
      });
    }
    // Backfill anything after the curated coverage with regime-derived
    // synthetic ticks so chapters beyond the curator's reach still show
    // mechanical roll cadence on the axis.
    const lastCovered = predictedRolls[predictedRolls.length - 1];
    if (lastCovered) {
      const synthetic = buildSyntheticCpTicks(story);
      const cutoffRaw = lastCovered.word_position;
      for (const s of synthetic) {
        if (s.word_position > cutoffRaw + 1000) {
          predictedRolls.push({ ...s, source: "synthetic" });
        }
      }
    }
  } else {
    predictedRolls = buildSyntheticCpTicks(story).map(s => ({ ...s, source: "synthetic" }));
  }

  _loaded = {
    pkg,
    CONSTELLATIONS: constellations,
    CONSTELLATION_ORDER,
    HUES,
    STORY: story,
    conByName,
    jumpWireframeByKey,
    constellationColor,
    povColor,
    sectionStyle,
    cpEarningAt: (w) => cpEarningAt(w, story),
    rawWordAtCpEarning: (t) => rawWordAtCpEarning(t, story),
    predictedRolls,
    cumulativeAt: (w) => cumulativeAt(w, story),
    chapterAtWord: (w) => chapterAtWord(w, story),
    lastRollAtWord: (w) => lastRollAtWord(w, story),
    recentRolls: (w, n = 10) => recentRolls(w, n, story),
    chapterIndex: (chapterNum) => story.chapters.findIndex(c => c.chapter_num === chapterNum),
  };
  Object.assign(window.BCF || (window.BCF = {}), _loaded);
  return _loaded;
}

// Eagerly populate the shell so other scripts can read static helpers
// without awaiting (the data fields will be added on load()).
window.BCF = {
  load,
  CONSTELLATION_ORDER,
  HUES,
  constellationColor,
};
