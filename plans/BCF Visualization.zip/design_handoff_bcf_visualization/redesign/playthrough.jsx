/* Playthrough mode — cinematic. Panoramic carousel of the 14 constellations
   drifts as the playhead advances; when a roll fires the active constellation
   sharpens and a jump-focus overlay opens onto the actual mote pattern from
   data/derived/constellation_wireframes.json. Joe's prose comes directly from
   roll.evidence_quotes whenever the curator pipeline has populated them. */

function ConstellationCard({ con, isActive, isFlank, lastHitJump }) {
  const size = 320;
  // The vertices and hull are already in [0..1] (data.js normalizes them).
  const hullPts = con.hull.map((p) => `${(p.x * size).toFixed(1)},${(p.y * size).toFixed(1)}`).join(" ");

  return (
    <div
      className={`const-card ${isActive ? "is-active" : ""} ${isFlank ? "is-flank" : ""}`}
      style={{ "--hue": con.hue }}>
      
      <span className="halo" />
      <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} className="outline"
      style={{ position: "absolute", inset: 0 }}>
        {/* Faint silhouette boundary so each constellation reads as a shape. */}
        <polygon points={hullPts} fill="none" strokeLinejoin="round" />
        {/* Filaments connecting each jump to its two nearest neighbors —
             implies the etched constellation lines. */}
        {(() => {
          const edges = [];
          for (let i = 0; i < con.vertices.length; i++) {
            const a = con.vertices[i];
            // pick the 2 nearest neighbors (so we don't draw every edge in O(n²))
            const others = con.vertices.slice(0, i).concat(con.vertices.slice(i + 1));
            others.sort((p, q) => Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y));
            for (const b of others.slice(0, 2)) {
              const key = a.jump < b.jump ? `${a.jump}|${b.jump}` : `${b.jump}|${a.jump}`;
              edges.push({ a, b, key });
            }
          }
          // dedupe
          const seen = new Set();
          return edges.filter((e) => seen.has(e.key) ? false : (seen.add(e.key), true)).map((e, i) =>
          <line key={i}
          x1={e.a.x * size} y1={e.a.y * size}
          x2={e.b.x * size} y2={e.b.y * size}
          strokeWidth="0.4"
          opacity="0.24" />

          );
        })()}
      </svg>
      {con.vertices.map((j) => {
        const isHit = lastHitJump === j.jump;
        // Map jump perkCount to a cost bucket so the diffraction recipe
        // gives bigger stars to jumps with more motes inside.
        const cost = j.perkCount >= 16 ? 800 : j.perkCount >= 10 ? 600 : j.perkCount >= 6 ? 400 : j.perkCount >= 3 ? 200 : 100;
        const visualSize = Math.max(28, Math.min(64, 18 + Math.sqrt(j.perkCount) * 7));
        const color = isHit ? "#fff" : `oklch(0.82 0.14 ${con.hue})`;
        return (
          <SimpleStar
            key={j.jump}
            color={color}
            cost={cost}
            themeKey="sun"
            visualSize={visualSize}
            opacity={isHit ? 1 : 0.92}
            style={{ left: `${j.x * 100}%`, top: `${j.y * 100}%`, transform: "translate(-50%, -50%)" }} />);


      })}
      <span className="meta">{con.vertices.length} jumps · {con.vertices.reduce((s, j) => s + j.perkCount, 0)} motes · {con.shape_concept.split(":")[0]}</span>
      <span className="label">{con.name}</span>
    </div>);

}

function Carousel({ activeConstellation, wordPos, panMode, lastHitJump }) {
  const { CONSTELLATIONS } = window.BCF;
  const cardWidth = 320 + 28;
  const idx = Math.max(0, CONSTELLATIONS.findIndex((c) => c.name === activeConstellation));
  const offset = -idx * cardWidth;

  // Subtle drift bias from word position — keeps motion alive between rolls.
  const drift = panMode === "drift" ?
  wordPos % 80000 / 80000 * 22 - 11 :
  panMode === "snap" ? 0 : wordPos % 60000 / 60000 * 10 - 5;

  return (
    <div
      className="carousel-strip"
      style={{
        transform: `translateX(calc(50% + ${offset + drift}px))`,
        transition: panMode === "snap" ? "transform 200ms steps(1, end)" : "transform 320ms cubic-bezier(.32,.08,.27,1)"
      }}>
      
      {CONSTELLATIONS.map((con, i) =>
      <ConstellationCard
        key={con.name}
        con={con}
        isActive={i === idx}
        isFlank={Math.abs(i - idx) === 1}
        lastHitJump={i === idx ? lastHitJump : null} />

      )}
    </div>);

}

function JumpFocus({ roll, theme, currentChapterIdx }) {
  const { conByName, jumpWireframeByKey, chapterIndex } = window.BCF;
  if (!roll || !roll.constellation || !roll.jump) {
    return <div className="jump-focus hidden" aria-hidden="true" />;
  }
  const con = conByName[roll.constellation];
  const key = `${roll.constellation}::${roll.jump}`;
  const jumpWf = jumpWireframeByKey.get(key);
  const color = `oklch(0.82 0.14 ${con?.hue ?? 196})`;
  const isHit = roll.outcome === "hit";

  // Mini-sky dimensions; stars are in [-1, 1] roughly.
  const skyW = 320,skyH = 220;
  const transform = (p) => ({
    x: (p.x + 1.4) / 2.8 * skyW,
    y: (p.y + 1.4) / 2.8 * skyH
  });
  const stars = jumpWf?.stars || [];

  // Match acquired perks by name to spot the rolled mote.
  const acquiredNames = new Set([
  ...(roll.purchased_perks || []).map((p) => p.name),
  ...(roll.free_perks || []).map((p) => p.name)]
  );

  // Resolve target star for the reach line.
  let target = null;
  if (isHit && stars.length) {
    target = stars.find((s) => acquiredNames.has(s.perk_name)) ||
    stars.find((s) => s.status === "Obtained") ||
    stars[0];
  } else if (stars.length) {
    target = stars.find((s) => s.status !== "Obtained") || stars[0];
  }

  let line = null;
  if (target) {
    const t = transform(target);
    const ox = skyW / 2,oy = skyH + 8;
    const dx = t.x - ox,dy = t.y - oy;
    const dist = Math.hypot(dx, dy);
    const useDist = isHit ? dist : dist * 0.72;
    const angle = Math.atan2(dy, dx) * 180 / Math.PI;
    line = { ox, oy, dist: useDist, angle };
  }

  const paidTotal = (roll.purchased_perks || []).reduce((s, p) => s + (p.cost || 0), 0);

  return (
    <div className={`jump-focus ${isHit ? "outcome-hit" : "outcome-miss"}`}>
      <div className="label">{roll.constellation} · roll {roll.roll_number}</div>
      <div className="jump-name">{roll.jump}</div>
      {jumpWf?.shape_concept &&
      <div style={{ marginTop: -8, marginBottom: 12, fontFamily: "var(--mono)", fontSize: 10, color: "var(--dim)", letterSpacing: ".08em", textTransform: "uppercase" }}>
          {jumpWf.shape_concept.split(":")[0]}
        </div>
      }
      <div className="mini-sky">
        <svg viewBox={`0 0 ${skyW} ${skyH}`} width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
          {stars.slice(1).map((s, i) => {
            const a = transform(stars[i]);
            const b = transform(s);
            return (
              <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y}
              stroke={color} strokeWidth="0.5" opacity="0.22" />);

          })}
        </svg>
        {stars.map((s, i) => {
          const t = transform(s);
          const isTarget = target && s.id === target.id;
          const acquiredIdx = s.acquired_chapter_num ? chapterIndex(s.acquired_chapter_num) : -1;
          const acquiredByNow = acquiredIdx >= 0 && acquiredIdx <= currentChapterIdx;
          // Star cost — use the actual CP cost stored in the wireframe.
          const starCost = s.cost || (s.size ? Math.round(s.size * 800) : 100);
          // Visual size: bigger for higher cost; the diffraction recipe handles
          // the cost-encoded ray length internally so we mostly tune the container.
          const visualSize = isTarget ? 60 : 24 + (s.size || 0.4) * 36;
          const op = isTarget ? 1 : acquiredByNow ? 0.92 : 0.22;
          const starColor = isTarget ? "#fff" : color;
          return (
            <SimpleStar
              key={s.id}
              color={starColor}
              cost={starCost}
              themeKey="sun"
              visualSize={visualSize}
              opacity={op}
              style={{
                left: `${t.x / skyW * 100}%`,
                top: `${t.y / skyH * 100}%`,
                transform: "translate(-50%, -50%)"
              }} />);


        })}
        {line &&
        <span
          className="reach-line"
          style={{ left: line.ox, top: line.oy, width: line.dist, transform: `rotate(${line.angle}deg)` }} />

        }
        <span style={{
          position: "absolute",
          left: skyW / 2, bottom: -4, marginLeft: -4,
          width: 8, height: 8,
          background: "rgba(255, 244, 184, 0.9)",
          borderRadius: "50%",
          boxShadow: "0 0 10px rgba(255, 244, 184, 0.6)"
        }} />
      </div>
      <div className="summary">
        <span>
          {isHit ?
          <span style={{ color: "var(--green)" }}>HIT · {(roll.purchased_perks || []).length} paid · {(roll.free_perks || []).length} free</span> :

          <span style={{ color: "var(--rose)" }}>MISS · est. {roll.miss_cost_estimate ?? "?"} CP</span>
          }
        </span>
        <span><strong>{paidTotal || roll.rolled_perk_cost || roll.miss_cost_estimate || 0}</strong> CP</span>
      </div>
    </div>);

}

function NarrativeReadout({ roll, chapter, showNarrative, onHide }) {
  const { conByName, recentRolls } = window.BCF;

  // Real prose from the story if we have any evidence_quotes; otherwise a
  // brief composed line that still names the constellation / jump.
  let body;
  if (roll && roll.evidence_quotes?.length && showNarrative) {
    body = roll.evidence_quotes.slice(0, 2).map((q, i) =>
    <p key={i} style={{ marginBottom: i < roll.evidence_quotes.length - 1 ? 12 : 0 }}>
        {q.text}
      </p>
    );
  } else if (roll) {
    const grabs = (roll.purchased_perks || []).length;
    const freeN = (roll.free_perks || []).length;
    const verb = roll.outcome === "hit" ?
    grabs >= 3 ? "swept across" : grabs === 2 ? "reached toward" : "reached for" :
    "brushed past";
    const tail = roll.outcome === "hit" ?
    grabs > 0 ?
    `grabbed ${grabs === 1 ? "a mote" : `${grabs} motes`} in the ${roll.jump || "—"} cluster${freeN ? ` (with ${freeN} smaller mote${freeN > 1 ? "s" : ""} bundled in)` : ""}.` :
    `caught something faint inside ${roll.jump || "—"}.` :
    `the mote it touched was beyond Joe's ${roll.available_cp ?? "?"} CP — it slipped away.`;
    body = <p>The Forge {verb} the <strong style={{ color: `oklch(0.78 0.13 ${conByName[roll.constellation]?.hue ?? 196})` }}>{roll.constellation}</strong> constellation and {tail}</p>;
  } else {
    body = (
      <p className="no-log">
        <span className="no-log-kicker">No log data</span>
        <span className="no-log-detail">ch {chapter.chapter_num} · the Forge is between reaches</span>
      </p>
    );
  }

  const recents = recentRolls(roll?.word_position ?? chapter.word_start, 8);

  return (
    <div className="panel panel-cut narrative" style={{ minHeight: 0 }}>
      <div className="panel-title">
        <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}>
          <span className="pip" /> Field log
          {roll && <span style={{ marginLeft: 8, color: "var(--dim)" }}>· {roll.evidence_kind?.replace(/_/g, " ")}</span>}
        </span>
        <span className="source">— Joe's event description</span>
      </div>
      <div className="narrative-body">
        {body}
        {roll &&
        <span className={`roll-line ${roll.outcome === "hit" ? "accent-hit" : "accent-miss"}`}>
            roll {roll.roll_number} · ch {roll.chapter_num} · {roll.outcome.toUpperCase()} ·
            {roll.outcome === "hit" ?
          ` paid ${(roll.purchased_perks || []).reduce((s, p) => s + p.cost, 0)} CP` :
          ` est. ${roll.miss_cost_estimate ?? "?"} CP miss`}
            {roll.available_cp != null && <> · {roll.available_cp} CP available</>}
          </span>
        }
      </div>
      <div className="recent-rolls">
        <div className="head">Recent reaches</div>
        <ol>
          {recents.map((r) =>
          <li key={r.uid} className={r.outcome}>
              <span className="dot" />
              <span className="roll-id">#{String(r.roll_number).slice(0, 6)}</span>
              <span>
                <span className="roll-where">{r.constellation || "—"}</span>
                <span style={{ display: "block", color: "var(--dim)", fontFamily: "var(--mono)", fontSize: 9.5, letterSpacing: ".06em", textTransform: "uppercase" }}>
                  {r.jump || "—"} · ch {r.chapter_num}
                </span>
              </span>
              <span className="roll-cost">
                {r.outcome === "hit" ?
              (r.purchased_perks || []).reduce((s, p) => s + p.cost, 0) + " CP" :
              r.miss_cost_estimate != null ? `miss ${r.miss_cost_estimate}` : "miss"}
              </span>
            </li>
          )}
        </ol>
      </div>
    </div>);

}

function Playthrough({ wordPos, lastRoll, theme, panMode = "smooth", showNarrative = true, fieldLogHidden = false, onHideFieldLog }) {
  const { STORY, chapterAtWord, chapterIndex } = window.BCF;
  const activeName = lastRoll?.constellation || "Toolkits";
  const chapter = chapterAtWord(wordPos);
  const currentChapterIdx = chapterIndex(chapter.chapter_num);
  // Tighter fire window: real rolls average ~3800 words apart, so ±900 keeps
  // each fire clean without lingering into the next roll.
  const firing = lastRoll && Math.abs(wordPos - lastRoll.word_position) < 900;
  const lastHitJump = firing && lastRoll?.outcome === "hit" ? lastRoll.jump : null;

  return (
    <div className={`playthrough ${fieldLogHidden ? "field-log-hidden" : ""}`}>
      <div className="viewport">
        <Starfield count={140} />
        <div className="viewport-hud">
          <span>sky lock · {(activeName || "drift").toLowerCase()}</span>
          <span className={firing ? "" : "warn"}>{firing ? "forge active" : "drift"}</span>
          <span>ch {chapter.chapter_num} / {STORY.chapters.length}</span>
        </div>
        <Carousel activeConstellation={activeName} wordPos={wordPos} panMode={panMode} lastHitJump={lastHitJump} />
        <div className="viewport-frame">
          <span className="corner tl" />
          <span className="corner tr" />
          <span className="corner bl" />
          <span className="corner br" />
        </div>
        {firing && lastRoll && <JumpFocus roll={lastRoll} theme={theme} currentChapterIdx={currentChapterIdx} />}
      </div>
      {!fieldLogHidden && (
        <NarrativeReadout
          roll={firing ? lastRoll : null}
          chapter={chapter}
          showNarrative={showNarrative}
          onHide={onHideFieldLog}
        />
      )}
    </div>);

}

Object.assign(window, { Playthrough, JumpFocus, NarrativeReadout, Carousel, ConstellationCard });