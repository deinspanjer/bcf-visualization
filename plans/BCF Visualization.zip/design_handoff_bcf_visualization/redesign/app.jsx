/* App root — header, info popover, scrubber + playback, mode. */

const STORY_LINKS = [
  { label: "SV", href: "https://forums.sufficientvelocity.com/threads/brocktons-celestial-forge-worm-jumpchain.70036/threadmarks" },
  { label: "FF", href: "https://www.fanfiction.net/s/13574944/1/Brockton-s-Celestial-Forge" },
  { label: "AO3", href: "https://archiveofourown.org/works/23949661/navigate" },
];
const STORY_TITLE_HREF = STORY_LINKS[0].href;
const PROJECT_REPO = "https://github.com/deinspanjer/bcf-visualization";

function useStored(key, initial) {
  const [val, setVal] = React.useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw == null ? initial : JSON.parse(raw);
    } catch { return initial; }
  });
  React.useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
  }, [key, val]);
  return [val, setVal];
}

function InfoPopover({ versionLabel, onClose }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const onDown = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);
  return (
    <div className="info-popover" ref={ref} role="dialog" aria-label="About this visualization">
      <h3>About</h3>
      <p>An interactive timeline for <em>Brockton's Celestial Forge</em> by LordRoustabout — scrub through the story to watch the Forge reach for power-cluster constellations across ~3 million words.</p>
      <p style={{ color: "var(--muted)", fontSize: 12.5 }}>The scrubber timeline plays in publish order; the sky carousel pans to whichever constellation the Forge has touched. Each star is a roll — color is constellation, size and rays encode CP cost, binary stars for multi-grabs.</p>

      <div className="info-shortcuts">
        <h4>Keyboard shortcuts</h4>
        <dl>
          <dt><kbd>space</kbd></dt><dd>play / pause</dd>
          <dt><kbd>← →</kbd></dt><dd>step (hold <kbd>shift</kbd> for fine)</dd>
          <dt><kbd>PgUp</kbd> / <kbd>PgDn</kbd></dt><dd>jump 100k words</dd>
          <dt><kbd>home</kbd> / <kbd>end</kbd></dt><dd>jump to start / end</dd>
        </dl>
      </div>

      <div className="meta-row">
        <span>Visualization by deinspanjer</span>
        <a className="gh-link" href={PROJECT_REPO} target="_blank" rel="noopener noreferrer">
          <svg viewBox="0 0 16 16" aria-hidden="true">
            <path d="M8 0.2a8 8 0 0 0-2.5 15.6c0.4 0.1 0.5-0.2 0.5-0.4v-1.4c-2.2 0.5-2.7-0.9-2.7-0.9-0.4-0.9-0.9-1.1-0.9-1.1-0.7-0.5 0.1-0.5 0.1-0.5 0.8 0.1 1.2 0.8 1.2 0.8 0.7 1.2 1.9 0.9 2.3 0.7 0.1-0.5 0.3-0.9 0.5-1.1-1.8-0.2-3.6-0.9-3.6-3.9 0-0.9 0.3-1.6 0.8-2.1-0.1-0.2-0.4-1 0.1-2.1 0 0 0.7-0.2 2.2 0.8a7.5 7.5 0 0 1 4 0c1.5-1 2.2-0.8 2.2-0.8 0.4 1.1 0.2 1.9 0.1 2.1 0.5 0.6 0.8 1.3 0.8 2.1 0 3-1.8 3.7-3.6 3.9 0.3 0.3 0.6 0.8 0.6 1.6v2.3c0 0.2 0.1 0.5 0.6 0.4A8 8 0 0 0 8 0.2Z"></path>
          </svg>
          github.com/deinspanjer/bcf-visualization
        </a>
        <span>{versionLabel}</span>
      </div>
    </div>
  );
}

function PortraitBanner() {
  const [dismissed, setDismissed] = useStored("bcf-redesign:portraitDismissed", false);
  if (dismissed) return null;
  return (
    <div className="portrait-banner is-visible" role="status">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <rect x="3" y="6" width="14" height="12" rx="1.5" />
        <path d="M19 9 L21 10.5 L19 12 M17.5 14 L21 14" strokeLinecap="round" />
      </svg>
      <span>
        <strong>Best in landscape.</strong> The Forge timeline reaches across ~3M words — rotating your device gives the scrubber room to breathe.
      </span>
      <button onClick={() => setDismissed(true)}>got it</button>
    </div>
  );
}

function StatStrip({ wordPos }) {
  const { cumulativeAt } = window.BCF;
  const cum = cumulativeAt(wordPos);
  return (
    <div className="stat-strip">
      <div><strong>ch {cum.chapter_label}</strong> position</div>
      <div><strong>{formatWords(cum.words)}</strong> words</div>
      <div><strong>{cum.paid}</strong> paid motes</div>
      <div><strong>{cum.free}</strong> free</div>
      <div><strong>{cum.hits}</strong> hits</div>
      <div><strong>{cum.miss}</strong> misses</div>
      {cum.banked_cp != null && <div><strong>{cum.banked_cp}</strong> CP banked</div>}
    </div>
  );
}

function LoadingScreen({ error }) {
  return (
    <div style={{ display: "grid", placeItems: "center", minHeight: "100vh", color: "var(--ink)" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--green)", letterSpacing: ".18em", textTransform: "uppercase", marginBottom: 12 }}>
          {error ? "Transmission failed" : "Establishing transmission"}
        </div>
        <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--ink)", textShadow: "0 0 12px var(--glow)" }}>
          {error ? <>Could not load <code style={{ fontFamily: "var(--mono)", fontSize: 14 }}>{error}</code></> : <>Loading the Forge sky…</>}
        </div>
        {!error && (
          <div style={{ marginTop: 20, width: 200, height: 2, background: "var(--edge-faint)", overflow: "hidden", margin: "20px auto 0" }}>
            <div style={{ width: "60%", height: "100%", background: "var(--cyan)", animation: "scan 1.4s linear infinite", boxShadow: "0 0 8px var(--cyan)" }} />
          </div>
        )}
      </div>
    </div>
  );
}

function App() {
  const [data, setData] = React.useState(null);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    window.BCF.load().then(setData).catch((e) => {
      console.error(e);
      setError(String(e.message || e));
    });
  }, []);

  const [wordPos, setWordPos] = useStored("bcf-redesign:wordPos", 50000);
  const [playing, setPlaying] = React.useState(false);
  const [speed, setSpeed] = useStored("bcf-redesign:speed", 25000);
  const [zoom, setZoom] = useStored("bcf-redesign:zoom", 1.2);
  const [mode, setMode] = useStored("bcf-redesign:mode", "playthrough");
  const [infoOpen, setInfoOpen] = React.useState(false);

  // Playback prefs (was inside the now-removed Tweaks panel).
  // Pause-on-fire and bullet-time are mutually exclusive: toggling one on
  // forces the other off so the user picks ONE behaviour for roll moments.
  const [pauseOnFire, setPauseOnFireRaw] = useStored("bcf-redesign:pauseOnFire", true);
  const [bulletTime, setBulletTimeRaw] = useStored("bcf-redesign:bulletTime", false);
  const setPauseOnFire = (v) => {
    setPauseOnFireRaw(v);
    if (v) setBulletTimeRaw(false);
  };
  const setBulletTime = (v) => {
    setBulletTimeRaw(v);
    if (v) setPauseOnFireRaw(false);
  };

  // Field log (right-hand "Survey transcribing Joe" panel in Playthrough)
  // is now user-collapsible — there's a close glyph on the panel, and a
  // page glyph at the end of the scrubber's chapter readout to reopen it.
  const [fieldLogHidden, setFieldLogHidden] = useStored("bcf-redesign:fieldLogHidden", false);

  // Bullet-time: when a roll is firing, drop playback to a very slow drift so
  // the user has time to actually read the Field Log entry. Window is wider
  // than the pause-on-fire trigger so the slowdown lingers either side of
  // the exact roll word position.
  const lastRoll = data ? data.lastRollAtWord(wordPos) : null;
  const firing = lastRoll && Math.abs(wordPos - lastRoll.word_position) < 700;
  const inBulletWindow = lastRoll && Math.abs(wordPos - lastRoll.word_position) < 1500;
  const effectiveSpeed = bulletTime && inBulletWindow ? speed * 0.04 : speed;

  // Playback loop.
  React.useEffect(() => {
    if (!playing || !data) return;
    let last = performance.now();
    let raf;
    const total = data.STORY.total_words;
    const tick = (now) => {
      const dt = (now - last) / 1000;
      last = now;
      setWordPos((prev) => {
        const next = prev + effectiveSpeed * dt;
        if (next >= total) { setPlaying(false); return total; }
        return Math.round(next);
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, effectiveSpeed, data]);

  // Global keyboard nav.
  React.useEffect(() => {
    if (!data) return;
    const total = data.STORY.total_words;
    const onKey = (e) => {
      const ae = document.activeElement;
      const tag = ae?.tagName;
      const editable = ae?.isContentEditable
        || tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
      if (e.key === " ") {
        if (editable) return;
        if (ae && tag === "BUTTON") ae.blur();
        setPlaying((p) => !p);
        e.preventDefault();
        return;
      }
      if (editable) return;
      const step = e.shiftKey ? 2000 : 10000;
      if (e.key === "ArrowRight") setWordPos((p) => Math.min(total, p + step));
      else if (e.key === "ArrowLeft") setWordPos((p) => Math.max(0, p - step));
      else if (e.key === "PageDown") setWordPos((p) => Math.min(total, p + 100000));
      else if (e.key === "PageUp") setWordPos((p) => Math.max(0, p - 100000));
      else if (e.key === "Home") setWordPos(0);
      else if (e.key === "End") setWordPos(total);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [data]);

  // Auto-pause on fire.
  React.useEffect(() => {
    if (!data || !pauseOnFire || !playing || !lastRoll || bulletTime) return;
    if (firing) {
      setPlaying(false);
      const t = setTimeout(() => {
        setWordPos((p) => p + 1400);
        setPlaying(true);
      }, 2200);
      return () => clearTimeout(t);
    }
  }, [wordPos, playing, lastRoll?.word_position, pauseOnFire, bulletTime, firing, data]);

  if (!data) return <LoadingScreen error={error} />;

  const versionLabel = data.pkg?.version_label || "BCF data";

  return (
    <div className="app">
      <header className="app-header">
        <div className="app-title">
          <h1>
            <a href={STORY_TITLE_HREF} target="_blank" rel="noopener noreferrer">Brockton's Celestial Forge</a>
          </h1>
          <span className="subject">Power Progression</span>
        </div>
        <div className="app-credits">
          <span className="by">Story by</span>
          <span className="author">LordRoustabout</span>
          {STORY_LINKS.map((l) => (
            <a key={l.label} className="site-badge" href={l.href} target="_blank" rel="noopener noreferrer">{l.label}</a>
          ))}
        </div>
        <div className="app-hint" aria-label="Keyboard shortcuts">
          <kbd>space</kbd> play/pause
          <span className="sep" aria-hidden="true">·</span>
          <kbd>← →</kbd> step
          <span className="sep" aria-hidden="true">·</span>
          <kbd>home</kbd><kbd>end</kbd> jump
          <span className="sep" aria-hidden="true">·</span>
          drag the track or click a star
        </div>
        <div className="app-mode-switch" style={{ marginLeft: "auto" }}>
          <button className={mode === "playthrough" ? "is-active" : ""} onClick={() => setMode("playthrough")}>Playthrough</button>
          <button className={mode === "detail" ? "is-active" : ""} onClick={() => setMode("detail")}>Detail</button>
        </div>
        <button
          className="info-button"
          aria-label="About this visualization"
          title="About"
          onClick={() => setInfoOpen((v) => !v)}
        >ⓘ</button>
        {infoOpen && <InfoPopover versionLabel={versionLabel} onClose={() => setInfoOpen(false)} />}
      </header>

      <PortraitBanner />

      <main className="app-main">
        <Scrubber
          wordPos={wordPos} setWordPos={setWordPos}
          compact={mode === "detail"} zoom={zoom} playing={playing}
          showFieldLogGlyph={mode === "playthrough" && fieldLogHidden}
          onShowFieldLog={() => setFieldLogHidden(false)}
        />
        <ScrubberControls
          playing={playing} setPlaying={setPlaying}
          speed={speed} setSpeed={setSpeed}
          zoom={zoom} setZoom={setZoom}
          pauseOnFire={pauseOnFire} setPauseOnFire={setPauseOnFire}
          bulletTime={bulletTime} setBulletTime={setBulletTime}
          onReset={() => { setWordPos(0); setPlaying(false); }}
        />
        <StatStrip wordPos={wordPos} />
        {mode === "playthrough"
          ? <Playthrough
              wordPos={wordPos} lastRoll={lastRoll}
              panMode="smooth" showNarrative={true}
              fieldLogHidden={fieldLogHidden}
              onHideFieldLog={() => setFieldLogHidden(true)}
            />
          : <Detail wordPos={wordPos} setWordPos={setWordPos} />
        }
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
