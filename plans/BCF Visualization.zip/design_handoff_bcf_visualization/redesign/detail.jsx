/* Detail mode — data-dense exploration with real perks + real rolls from
   chapter_facts.json. Three top panels (Selected chapter perks · Recent
   acquisitions · Constellation progress) and a sortable roll log spanning
   the full width below. */

function SelectedChapter({ wordPos, theme }) {
  const { chapterAtWord, conByName } = window.BCF;
  const chapter = chapterAtWord(wordPos);
  const items = [];
  for (const r of chapter.rolls) {
    for (const p of r.purchased_perks || []) items.push({ name: p.name, cost: p.cost, free: !!p.free, roll: r });
    for (const p of r.free_perks || []) items.push({ name: p.name, cost: 0, free: true, jump: p.jump, roll: r });
  }

  const markers = chapter.structural_markers || [];

  return (
    <div className="panel panel-cut detail-panel">
      <div className="panel-title"><span className="pip" /> Selected chapter</div>
      <div className="body">
        <div style={{ marginBottom: 12, fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted)", letterSpacing: ".08em", textTransform: "uppercase" }}>
          <strong style={{ color: "var(--ink)", fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 16, marginRight: 8, textTransform: "none", letterSpacing: 0 }}>
            ch {chapter.chapter_num} — {chapter.title}
          </strong>
          <span>{chapter.pov}</span>
          <span style={{ margin: "0 8px", color: "var(--dim)" }}>·</span>
          <span>{chapter.publish_date}</span>
          <span style={{ margin: "0 8px", color: "var(--dim)" }}>·</span>
          <span>{chapter.total_word_count.toLocaleString()} words</span>
          {markers.length > 0 && <>
            <span style={{ margin: "0 8px", color: "var(--dim)" }}>·</span>
            <span style={{ color: "var(--amber)" }}>{markers.join(" · ")}</span>
          </>}
          {chapter.recovery && <>
            <span style={{ margin: "0 8px", color: "var(--dim)" }}>·</span>
            <span style={{ color: "var(--rose)" }} title={`Recovery from ${chapter.recovery_trigger || "high-cost perk"}`}>recovery shadow</span>
          </>}
          {chapter.banked_cp_at_end != null && <>
            <span style={{ margin: "0 8px", color: "var(--dim)" }}>·</span>
            <span>{chapter.banked_cp_at_end} CP banked</span>
          </>}
        </div>
        {items.length === 0 ? (
          <p style={{ fontFamily: "var(--serif)", color: "var(--muted)", margin: 0, fontStyle: "italic" }}>
            No motes were caught in this chapter. The Forge stayed quiet.
          </p>
        ) : (
          <ul className="perk-list">
            {items.map((p, i) => {
              const con = conByName[p.roll.constellation];
              const color = `oklch(0.78 0.13 ${con?.hue ?? 196})`;
              return (
                <li key={i}>
                  <span className="perk-marker">
                    <DiffractionMarker
                      roll={{ outcome: "hit", purchased_perks: [{ cost: p.cost || 100 }], free_perks: [] }}
                      themeKey={theme}
                      scale={0.6}
                      color={color}
                    />
                  </span>
                  <span>
                    <span className="perk-name">{p.name}</span>
                    <span className="perk-source">{p.roll.constellation || "—"} · {p.jump || p.roll.jump || p.roll.purchased_perk_jump || "—"}</span>
                  </span>
                  <span className={`perk-cost ${p.free ? "free" : ""}`}>
                    {p.free ? "FREE" : `${p.cost} CP`}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}

function RecentAcquisitions({ wordPos, theme }) {
  const { recentRolls, conByName } = window.BCF;
  const recents = recentRolls(wordPos, 20).filter(r => r.outcome === "hit");
  const items = [];
  for (const r of recents) {
    for (const p of r.purchased_perks) items.push({ name: p.name, cost: p.cost, free: false, roll: r });
    for (const p of r.free_perks) items.push({ name: p.name, cost: 0, free: true, jump: p.jump, roll: r });
    if (items.length >= 14) break;
  }
  return (
    <div className="panel panel-cut detail-panel">
      <div className="panel-title"><span className="pip" /> Most recent acquisitions</div>
      <div className="body">
        {items.length === 0 ? (
          <p style={{ color: "var(--muted)", fontFamily: "var(--serif)", fontStyle: "italic" }}>No motes acquired yet.</p>
        ) : (
          <ul className="perk-list">
            {items.slice(0, 14).map((p, i) => {
              const con = conByName[p.roll.constellation];
              const color = `oklch(0.78 0.13 ${con?.hue ?? 196})`;
              return (
                <li key={`${p.roll.roll_number}-${i}`}>
                  <span className="perk-marker">
                    <DiffractionMarker
                      roll={{ outcome: "hit", purchased_perks: [{ cost: p.cost || 100 }], free_perks: [] }}
                      themeKey={theme}
                      scale={0.55}
                      color={color}
                    />
                  </span>
                  <span>
                    <span className="perk-name">{p.name}</span>
                    <span className="perk-source">{p.roll.constellation || "—"} · {p.jump || p.roll.jump || "—"} · ch {p.roll.chapter_num}</span>
                  </span>
                  <span className={`perk-cost ${p.free ? "free" : ""}`}>
                    {p.free ? "FREE" : `${p.cost} CP`}
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}

function ConstellationBars({ wordPos }) {
  const { chapterAtWord, CONSTELLATIONS, HUES } = window.BCF;
  const chapter = chapterAtWord(wordPos);
  const progressByName = new Map((chapter.constellation_progress || []).map(p => [p.name, p]));

  return (
    <div className="panel panel-cut detail-panel">
      <div className="panel-title"><span className="pip" /> Constellation progress</div>
      <div className="body">
        <div className="constellation-bars">
          {CONSTELLATIONS.map(c => {
            const p = progressByName.get(c.name) || { discovered: 0, total: 0, discovered_pct: 0, count: 0 };
            const pct = p.discovered_pct;
            const color = `oklch(0.78 0.13 ${HUES[c.name] ?? 196})`;
            return (
              <div className="bar-row" key={c.name}>
                <span className="name">{c.name}</span>
                <span className="bar">
                  <span style={{ width: `${pct}%`, "--bar-color": color }} />
                </span>
                <span className="count">{p.discovered} / {p.total}</span>
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--edge-faint)", fontFamily: "var(--mono)", fontSize: 9.5, color: "var(--dim)", letterSpacing: ".08em", textTransform: "uppercase" }}>
          Percentage shows perks DISCOVERED in catalog, not just acquired
        </div>
      </div>
    </div>
  );
}

function RollLog({ wordPos, setWordPos, theme }) {
  const { STORY, conByName } = window.BCF;
  const [sortBy, setSortBy] = React.useState("roll");
  const [filter, setFilter] = React.useState("all");

  const rolls = React.useMemo(() => {
    let rs = STORY.rolls.filter(r => r.word_position <= wordPos);
    if (filter === "hit") rs = rs.filter(r => r.outcome === "hit");
    if (filter === "miss") rs = rs.filter(r => r.outcome === "miss");
    if (filter === "multi") rs = rs.filter(r => (r.purchased_perks || []).length >= 2);
    rs = [...rs];
    if (sortBy === "roll") rs.sort((a, b) => b.word_position - a.word_position);
    if (sortBy === "cost") rs.sort((a, b) =>
      (b.purchased_perks || []).reduce((s, p) => s + p.cost, 0)
      - (a.purchased_perks || []).reduce((s, p) => s + p.cost, 0));
    if (sortBy === "chapter") rs.sort((a, b) => (b.chapter_num.localeCompare(a.chapter_num, undefined, { numeric: true })));
    return rs;
  }, [wordPos, sortBy, filter, STORY]);

  return (
    <div className="panel panel-cut detail-panel full-row">
      <div className="panel-title">
        <span className="pip" /> Roll log
        <span style={{ marginLeft: 12, color: "var(--dim)", fontWeight: 400, letterSpacing: ".08em", fontSize: 10 }}>
          {rolls.length} shown
        </span>
        <span style={{ marginLeft: "auto", display: "inline-flex", gap: 12, alignItems: "center" }}>
          <span style={{ color: "var(--dim)" }}>filter</span>
          {["all", "hit", "miss", "multi"].map(f => (
            <button key={f}
              className="btn ghost"
              style={{ minHeight: 24, padding: "4px 8px", fontSize: 9, color: filter === f ? "var(--ink)" : "var(--muted)", borderColor: filter === f ? "var(--edge)" : "var(--edge-faint)" }}
              onClick={() => setFilter(f)}
            >{f}</button>
          ))}
          <span style={{ color: "var(--dim)", marginLeft: 8 }}>sort</span>
          {["roll", "chapter", "cost"].map(s => (
            <button key={s}
              className="btn ghost"
              style={{ minHeight: 24, padding: "4px 8px", fontSize: 9, color: sortBy === s ? "var(--ink)" : "var(--muted)", borderColor: sortBy === s ? "var(--edge)" : "var(--edge-faint)" }}
              onClick={() => setSortBy(s)}
            >{s}</button>
          ))}
        </span>
      </div>
      <div className="body" style={{ padding: 0, overflow: "auto" }}>
        <table className="roll-log">
          <thead>
            <tr>
              <th>#</th>
              <th>Ch</th>
              <th>Word</th>
              <th>Outcome</th>
              <th>Constellation</th>
              <th>Jump</th>
              <th>Mote(s)</th>
              <th style={{ textAlign: "right" }}>CP paid</th>
              <th style={{ textAlign: "right" }}>CP avail</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rolls.slice(0, 250).map(r => {
              const con = conByName[r.constellation];
              const color = `oklch(0.78 0.13 ${con?.hue ?? 196})`;
              const paid = (r.purchased_perks || []).reduce((s, p) => s + p.cost, 0);
              const names = [
                ...(r.purchased_perks || []).map(p => p.name),
                ...(r.free_perks || []).map(p => `${p.name} (free)`),
              ];
              return (
                <tr key={r.uid} onClick={() => setWordPos(r.word_position)} style={{ cursor: "pointer" }}>
                  <td style={{ width: 44, color: "var(--dim)" }}>{String(r.roll_number).slice(0, 6)}</td>
                  <td style={{ width: 50 }}>{r.chapter_num}</td>
                  <td style={{ width: 80 }}>{r.word_position.toLocaleString()}</td>
                  <td className={`outcome-${r.outcome}`} style={{ width: 70, textTransform: "uppercase", fontWeight: 800, fontSize: 10 }}>{r.outcome}</td>
                  <td style={{ color, width: 170, letterSpacing: ".06em", textTransform: "uppercase", fontSize: 10 }}>{r.constellation || "—"}</td>
                  <td style={{ width: 200 }}>{r.jump || "—"}</td>
                  <td className="perk-cell">{names.length ? names.join(" · ") : "—"}</td>
                  <td style={{ textAlign: "right", color: r.outcome === "hit" ? "var(--green)" : "var(--dim)", width: 70 }}>
                    {r.outcome === "hit" ? paid : (r.miss_cost_estimate ?? "—")}
                  </td>
                  <td style={{ textAlign: "right", color: "var(--muted)", width: 70 }}>{r.available_cp ?? "—"}</td>
                  <td style={{ width: 36 }}>
                    <DiffractionMarker roll={r} themeKey={theme} scale={0.5} color={color} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Detail({ wordPos, setWordPos, theme }) {
  return (
    <div className="detail">
      <SelectedChapter wordPos={wordPos} theme={theme} />
      <RecentAcquisitions wordPos={wordPos} theme={theme} />
      <ConstellationBars wordPos={wordPos} />
      <RollLog wordPos={wordPos} setWordPos={setWordPos} theme={theme} />
    </div>
  );
}

Object.assign(window, { Detail, SelectedChapter, RecentAcquisitions, ConstellationBars, RollLog });
