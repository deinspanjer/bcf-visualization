/* Diffraction-spike star marker.
   Built around the recipe in web/marker-samples.html — kept faithful to the
   user's tuning of cost → ray count / length / glow. Five themes are
   selectable via tweaks. Single SVG instance; multi-grab uses a wrapper
   span that places multiple star SVGs in a binary/trinary cluster. */

const STAR_THEMES = {
  thin: { spread: 3.05, primaryOpacity: 0.76, secondaryOpacity: 0.15, whiteGlow: 0.7, colorGlow: 1.9, tintOpacity: 0.12 },
  sun:  { spread: 3.35, primaryOpacity: 0.68, secondaryOpacity: 0.32, whiteGlow: 0.8, colorGlow: 2.4, tintOpacity: 0.12 },
  sharp:{ spread: 2.80, primaryOpacity: 0.86, secondaryOpacity: 0.08, whiteGlow: 0.45, colorGlow: 1.15, tintOpacity: 0.08 },
  lumin:{ spread: 3.20, primaryOpacity: 0.48, secondaryOpacity: 0.22, whiteGlow: 1.3,  colorGlow: 5.0, tintOpacity: 0.10, opacity: 0.68 },
  prism:{ spread: 3.45, primaryOpacity: 0.60, secondaryOpacity: 0.34, whiteGlow: 0.65, colorGlow: 2.2, tintOpacity: 0.10 },
};

function luminosityFor(cost) {
  if (cost >= 1000) return 1.32;
  if (cost >= 800) return 1.20;
  if (cost >= 600) return 1.05;
  if (cost >= 400) return 0.86;
  if (cost >= 300) return 0.76;
  if (cost >= 200) return 0.64;
  return 0.52;
}

function markerSizeFor(cost, structure) {
  let base = cost >= 1000 ? 32 : cost >= 800 ? 31 : cost >= 600 ? 30 : cost >= 400 ? 28 : cost >= 300 ? 27 : cost >= 200 ? 26 : 24;
  if (structure === "binary") base += 4;
  if (structure === "trinary") base += 6;
  if (structure === "sat3") base += 3;
  return base;
}

function recipeFor(cost, themeKey) {
  let base = cost >= 1000 ? { major: 12, minor: 12, length: 47, width: 1.1, minorLength: 32, minorWidth: 0.34, jitter: 10 }
    : cost >= 800 ? { major: 10, minor: 10, length: 44, width: 1.05, minorLength: 29, minorWidth: 0.32, jitter: 8 }
    : cost >= 600 ? { major: 8, minor: 8, length: 40, width: 0.98, minorLength: 25, minorWidth: 0.30, jitter: 6 }
    : cost >= 400 ? { major: 6, minor: 6, length: 36, width: 0.90, minorLength: 21, minorWidth: 0.28, jitter: 4 }
    : cost >= 300 ? { major: 5, minor: 5, length: 32, width: 0.82, minorLength: 18, minorWidth: 0.26, jitter: 3 }
    : cost >= 200 ? { major: 4, minor: 4, length: 29, width: 0.75, minorLength: 14, minorWidth: 0.24, jitter: 2 }
    :               { major: 3, minor: 3, length: 26, width: 0.68, minorLength: 11, minorWidth: 0.22, jitter: 0 };

  if (themeKey === "thin")  base = { ...base, minor: Math.min(base.minor, 3), width: base.width * 0.7, minorWidth: base.minorWidth * 0.65, length: base.length * 0.9 };
  if (themeKey === "sun")   base = { ...base, major: base.major + 2, minor: base.minor + 2, length: base.length * 1.06, minorLength: base.minorLength * 1.18 };
  if (themeKey === "sharp") base = { ...base, minor: Math.min(base.minor, 4), width: base.width * 0.55, minorWidth: base.minorWidth * 0.5, length: base.length * 0.82 };
  if (themeKey === "lumin") base = { ...base, width: base.width * 0.62, minorWidth: base.minorWidth * 0.55, length: base.length * 0.78, minorLength: base.minorLength * 0.92 };
  if (themeKey === "prism") base = { ...base, length: base.length * 1.08, minorLength: base.minorLength * 1.35, jitter: base.jitter + 9 };
  return base;
}

let __starId = 0;

function StarSvg({ color, cost, themeKey = "sun", pixelSize = 60 }) {
  const theme = STAR_THEMES[themeKey] || STAR_THEMES.sun;
  const r = recipeFor(cost, themeKey);
  const lum = luminosityFor(cost);
  const gradId = React.useMemo(() => `ray-${++__starId}`, []);

  const rays = (count, length, width, offset = 0) =>
    Array.from({ length: count }, (_, idx) => {
      const angle = (360 / count) * idx + offset + (idx % 2 ? r.jitter : -r.jitter);
      const finalLength = length * (idx % 3 === 0 ? 1.10 : 1);
      return (
        <rect
          key={idx}
          x={-finalLength}
          y={-width / 2}
          width={finalLength * 2}
          height={width}
          rx={width / 2}
          fill={`url(#${gradId})`}
          transform={`rotate(${angle.toFixed(2)})`}
        />
      );
    });

  const filter = `drop-shadow(0 0 ${(lum * theme.whiteGlow).toFixed(2)}px #fff) drop-shadow(0 0 ${(lum * theme.colorGlow).toFixed(2)}px ${color})`;

  return (
    <svg viewBox="-50 -50 100 100" aria-hidden="true" focusable="false"
         style={{
           position: "absolute", left: "50%", top: "50%",
           transform: "translate(-50%, -50%)",
           width: pixelSize, height: pixelSize,
           overflow: "visible",
           opacity: theme.opacity ?? 0.76,
           filter,
           pointerEvents: "none",
         }}>
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="transparent" />
          <stop offset="0.34" stopColor={color} stopOpacity="0.075" />
          <stop offset="0.48" stopColor="#fff" stopOpacity="0.58" />
          <stop offset="0.50" stopColor="#fff" stopOpacity="0.92" />
          <stop offset="0.52" stopColor="#fff" stopOpacity="0.58" />
          <stop offset="0.66" stopColor={color} stopOpacity="0.075" />
          <stop offset="1" stopColor="transparent" />
        </linearGradient>
      </defs>
      <g opacity={theme.primaryOpacity} style={{ mixBlendMode: "screen" }}>
        {rays(r.major, r.length, r.width)}
      </g>
      <g opacity={theme.secondaryOpacity} style={{ mixBlendMode: "screen" }}>
        {rays(r.minor, r.minorLength, r.minorWidth, 360 / (r.major * 2))}
      </g>
      <circle r={2.6 + lum * 1.8} fill={color} opacity={theme.tintOpacity} />
      <circle r={1.2 + lum * 0.62} fill="#fff" style={{ filter: "drop-shadow(0 0 1.2px #fff)" }} />
    </svg>
  );
}

// Public wrapper. `roll` is a roll fact; we render the structure (single /
// binary / trinary) plus optional free satellites. Misses get a single
// small white star — sized by their estimated cost — so they read as
// faint sparkles on the lower lane rather than empty bullet holes.
function DiffractionMarker({ roll, themeKey = "sun", scale = 1, color }) {
  if (!roll) return null;
  const theme = STAR_THEMES[themeKey] || STAR_THEMES.sun;
  // Star SVG floor: matches marker-samples.html (`min-width: 46px`) so the
  // rays read as a star even when scale is small (e.g. on the dense scrubber).
  const SVG_MIN = 46;
  const SVG_MAX = 124;
  const svgFor = (markerSize) =>
    Math.max(SVG_MIN, Math.min(SVG_MAX, markerSize * theme.spread));

  if (roll.outcome === "miss") {
    const missCost = roll.miss_cost_estimate || roll.rolled_perk_cost || 100;
    const size = markerSizeFor(missCost, "single") * scale * 0.78;
    return (
      <span style={{
        position: "relative",
        display: "inline-block",
        width: size, height: size,
        verticalAlign: "middle",
      }}>
        <span style={{
          position: "absolute", left: "50%", top: "50%",
          width: size * 0.22, height: size * 0.22,
          transform: "translate(-50%, -50%)",
        }}>
          <StarSvg color="#cfe9ff" cost={missCost} themeKey={themeKey} pixelSize={svgFor(size)} />
        </span>
      </span>
    );
  }
  const paid = roll.purchased_perks || [];
  const free = roll.free_perks || [];
  const grabs = paid.length;
  const structure = grabs >= 3 ? "trinary" : grabs === 2 ? "binary" : (free.length > 0 ? "sat1" : "single");
  const cost = paid.reduce((s, p) => s + (p.cost || 0), 0) || 100;
  const size = markerSizeFor(cost, structure) * scale;
  const c = color || "#71cef9";

  const starPositions = structure === "binary"
    ? [{ dx: -6, dy: 2, s: 0.86 }, { dx: 7, dy: -2, s: 0.80 }]
    : structure === "trinary"
      ? [{ dx: -8, dy: 4, s: 0.72 }, { dx: 8, dy: 4, s: 0.72 }, { dx: 0, dy: -8, s: 0.82 }]
      : [{ dx: 0, dy: 0, s: 1.0 }];

  const sats = structure === "sat1" ? 1 : (free.length >= 3 ? 3 : free.length);

  return (
    <span style={{
      position: "relative",
      display: "inline-block",
      width: size, height: size,
      verticalAlign: "middle",
    }}>
      {starPositions.map((p, i) => (
        <span key={i} style={{
          position: "absolute", left: "50%", top: "50%",
          width: size * 0.22, height: size * 0.22,
          transform: `translate(calc(-50% + ${p.dx}px), calc(-50% + ${p.dy}px)) scale(${p.s})`,
        }}>
          <StarSvg color={c} cost={paid[i]?.cost || cost} themeKey={themeKey} pixelSize={svgFor(size)} />
        </span>
      ))}
      {Array.from({ length: sats }, (_, i) => {
        const placements = [
          { x: 0, y: -15 },
          { x: 15, y: 0 },
          { x: -11, y: -11 },
        ];
        const p = placements[i % placements.length];
        return (
          <span key={`sat-${i}`} style={{
            position: "absolute", left: "50%", top: "50%",
            width: 3.2, height: 3.2,
            borderRadius: "50%",
            background: "#fff",
            opacity: 0.85,
            boxShadow: `0 0 2px #fff, 0 0 4px ${c}`,
            transform: `translate(calc(-50% + ${p.x}px), calc(-50% + ${p.y}px))`,
          }} />
        );
      })}
    </span>
  );
}

// Background twinkle field for the viewport.
function Starfield({ count = 90, seed = 71 }) {
  const stars = React.useMemo(() => {
    let s = seed;
    const r = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    return Array.from({ length: count }, (_, i) => ({
      x: r() * 100,
      y: r() * 100,
      dim: r() > 0.6,
    }));
  }, [count, seed]);
  return (
    <div className="starfield" aria-hidden="true">
      {stars.map((st, i) => (
        <span
          key={i}
          className={`bg-star ${st.dim ? "dim" : ""}`}
          style={{ left: `${st.x}%`, top: `${st.y}%` }}
        />
      ))}
    </div>
  );
}

// Single-star variant — used wherever we want one star without the
// multi-grab / satellite structure of DiffractionMarker. `visualSize` is the
// approximate on-screen diameter of the glow (the SVG spreads ~3x its
// container, so we shrink the container accordingly).
function SimpleStar({ color = "#71cef9", cost = 100, themeKey = "sun", visualSize = 14, opacity = 1, style = {} }) {
  // visualSize is the on-screen diameter of the rendered star (rays included),
  // so we hand it straight to StarSvg as pixelSize. The wrapper span carries
  // positioning/transform but doesn't constrain the SVG.
  return (
    <span style={{
      position: "absolute",
      width: 0, height: 0,
      opacity,
      ...style,
    }}>
      <StarSvg color={color} cost={cost} themeKey={themeKey} pixelSize={visualSize} />
    </span>
  );
}

Object.assign(window, { DiffractionMarker, StarSvg, SimpleStar, Starfield, STAR_THEMES });
